-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2024 at 05:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_construction`
--

-- --------------------------------------------------------

--
-- Table structure for table `subsemail`
--

CREATE TABLE `subsemail` (
  `id` int(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `adminUser` varchar(255) NOT NULL,
  `adminEmail` varchar(255) NOT NULL,
  `adminPassword` varchar(32) NOT NULL,
  `level` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`adminId`, `adminName`, `adminUser`, `adminEmail`, `adminPassword`, `level`) VALUES
(1, 'zeroprogrammers', 'superadmin', 'zero@sliit.lk', '12345678', 'staff'),
(6, 'udghe', 'dgeedg@he', 'auhaju@gc', '1234gfhyh', 'staff'),
(7, 'udghe', 'dgeedg@he', 'auhaju@gc', '1234gfhyh', 'staff'),
(8, 'udghe', 'dgeedg@he', 'auhaju@gc', '1234gfhyh', 'staff'),
(14, 'zeroprogrammers', 'superadmin', 'zero@sliit.lk', '12345678', 'superadmin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `cartId` int(11) NOT NULL,
  `sId` varchar(255) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Pending',
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `dateofjoin` date NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `dob`, `address`, `dateofjoin`, `phone`, `email`, `pass`) VALUES
(2, 'Jane Smi', '1985-07-22', '456 Oak Avenue, Metropolis', '0000-00-00', '1234567890', 'jane.smith@example.com', '$2y$10$52gBBxFPxGaCmVfr6JrTLusNZ'),
(3, 'Alice Johnson', '1992-11-30', '789 Pine Road, Gotham', '2021-01-10', '555-8765', 'alice.johnson@example.com', 'alice789'),
(4, 'Bob Brown', '1988-05-14', '321 Birch Lane, Star City', '2018-09-25', '555-4321', 'bob.brown@example.com', 'bobpass321'),
(5, 'Carol White', '1995-03-08', '654 Cedar Street, Central City', '2022-07-19', '555-6789', 'carol.white@example.com', 'carolpass654'),
(6, 'dsgfs', '2024-10-01', 'cxcx33', '0000-00-00', '0778304546', 'zero@sliit.lk', '$2y$10$vLI5oxTHcfzTnFEc6cPkAeaOb');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `nic` varchar(12) NOT NULL,
  `name` varchar(30) NOT NULL,
  `gender` int(11) NOT NULL,
  `doj` date NOT NULL DEFAULT current_timestamp(),
  `dob` date NOT NULL,
  `jobtitle` varchar(10) NOT NULL,
  `empcat` varchar(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `hirestatus` varchar(5) NOT NULL,
  `hourssalary` float NOT NULL,
  `age` int(11) NOT NULL,
  `address` varchar(50) NOT NULL,
  `pw` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`nic`, `name`, `gender`, `doj`, `dob`, `jobtitle`, `empcat`, `Email`, `phoneno`, `hirestatus`, `hourssalary`, `age`, `address`, `pw`) VALUES
('556677889V', 'Bob Brown', 0, '2018-09-25', '1988-05-14', 'HR Manager', 'Full-Time', 'bob.brown@example.com', '555-4321', 'Activ', 40, 36, '321 Birch Lane, Star City', 'bobpass321'),
('987654321V', 'Jane Smith', 0, '2019-03-15', '1985-07-22', 'Project Ma', 'Full-Time', 'jane.smith@example.com', '555-5678', 'Activ', 45, 39, '456 Oak Avenue, Metropolis', 'qwerty456'),
('998877665V', 'Carol White', 0, '2022-07-19', '1995-03-08', 'Marketing ', 'Full-Time', 'carol.white@example.com', '555-6789', 'Activ', 40, 29, '654 Cedar Street, Central City', 'carolpass654');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `orderId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `paymentMethod` varchar(50) NOT NULL,
  `orderTotal` decimal(10,2) NOT NULL,
  `orderStatus` varchar(50) NOT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_orderdetails`
--

CREATE TABLE `tbl_orderdetails` (
  `orderDetailId` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `productId` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`productId`, `productName`, `body`, `price`, `image`, `type`) VALUES
(23, 'Steel Rebar', 'High tensile strength steel rebar for reinforced concrete.', 800.00, '', 0),
(24, 'Safety Helmet', 'Durable safety helmet with adjustable straps.', 25.00, 'safety_helmet.jpg', 0),
(25, 'Excavator', 'Heavy-duty excavator with a 1.5m³ bucket capacity.', 75000.00, 'excavator.jpg', 0),
(26, 'Cement Bags', '50kg bags of high-quality cement.', 10.00, 'cement_bags.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_vehicle`
--

CREATE TABLE `tbl_vehicle` (
  `v_id` int(11) NOT NULL,
  `v_name` varchar(99) NOT NULL,
  `v_model` varchar(50) NOT NULL,
  `v_yom` varchar(9) NOT NULL,
  `v_lsd` date NOT NULL,
  `fueltype` varchar(10) NOT NULL,
  `image` varchar(50) NOT NULL,
  `capacity` varchar(20) NOT NULL,
  `milage` varchar(20) NOT NULL,
  `regno` varchar(10) NOT NULL,
  `rentstatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_vehicle`
--

INSERT INTO `tbl_vehicle` (`v_id`, `v_name`, `v_model`, `v_yom`, `v_lsd`, `fueltype`, `image`, `capacity`, `milage`, `regno`, `rentstatus`) VALUES
(8, 'Dump Truck', 'HD785-7', '20023', '2024-04-01', '5656', 'dumptruck_dt300.jpg', 'gjgj', '8', 'Dump098', 'Available'),
(9, 'Concrete Mixer', 'YM0115', '2018', '2024-09-15', 'Diesel', 'concretemixer_cm400.jpg', '16', '7', 'CD789EF', 'Rented'),
(10, 'Tractor', '6M 145', '2011', '2024-03-05', 'Diesel', 'crane_cr500.jpg', '8', '4', 'CH012IJ', 'Available'),
(12, 'dsdsdx', 'fddsf', '2002', '0000-00-00', 'petol', 'sd', '100', '100', '123ddddd', 'available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `subsemail`
--
ALTER TABLE `subsemail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`nic`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `tbl_orderdetails`
--
ALTER TABLE `tbl_orderdetails`
  ADD PRIMARY KEY (`orderDetailId`),
  ADD KEY `orderId` (`orderId`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `tbl_vehicle`
--
ALTER TABLE `tbl_vehicle`
  ADD PRIMARY KEY (`v_id`),
  ADD UNIQUE KEY `regno` (`regno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `subsemail`
--
ALTER TABLE `subsemail`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_cart`
--
ALTER TABLE `tbl_cart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_orderdetails`
--
ALTER TABLE `tbl_orderdetails`
  MODIFY `orderDetailId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `productId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tbl_vehicle`
--
ALTER TABLE `tbl_vehicle`
  MODIFY `v_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_orderdetails`
--
ALTER TABLE `tbl_orderdetails`
  ADD CONSTRAINT `tbl_orderdetails_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `tbl_order` (`orderId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
