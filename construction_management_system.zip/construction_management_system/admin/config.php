<?php
// define variable
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_construction";

// Create conn
$conn = new mysqli($servername, $username, $password, $dbname);

// Check
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
