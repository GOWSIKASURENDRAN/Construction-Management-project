document.addEventListener('DOMContentLoaded', function() {
    var form = document.querySelector('.form-container');
    var passwordInput = form.querySelector('input[name="adminPassword"]');
    var confirmPasswordInput = document.createElement('input');
    var emailInput = form.querySelector('input[name="adminEmail"]');
    var nameInput = form.querySelector('input[name="adminName"]');
    var submitButton = form.querySelector('button[type="submit"]');

    // Create confirm password field
    confirmPasswordInput.type = 'password';
    confirmPasswordInput.placeholder = 'Confirm Password';
    confirmPasswordInput.required = true;
    confirmPasswordInput.name = 'confirmPassword';
    form.insertBefore(confirmPasswordInput, submitButton);

    // Function to validate email format
    function validateEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // Function to validate password strength
    function validatePassword(password) {
        // Minimum 8 characters, at least one uppercase letter, one lowercase letter, one number, and one special character
        var re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return re.test(password);
    }

    // Add event listener for form submission
    form.addEventListener('submit', function(event) {
        var password = passwordInput.value;
        var confirmPassword = confirmPasswordInput.value;
        var email = emailInput.value;
        var name = nameInput.value;

        if (!name.trim()) {
            alert('Please enter a valid name.');
            event.preventDefault(); // Prevent form submission
            return;
        }

        if (!validateEmail(email)) {
            alert('Please enter a valid email address.');
            event.preventDefault(); // Prevent form submission
            return;
        }

        if (!validatePassword(password)) {
            alert('Password must be at least 8 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.');
            event.preventDefault(); // Prevent form submission
            return;
        }

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            event.preventDefault(); // Prevent form submission
        }
    });
});
