document.getElementById('nic').addEventListener('input', function () {
    var nic = this.value;
    var dobInput = document.getElementById('dob');
    var genderRadios = document.getElementsByName('gender');
    var ageInput = document.getElementById('age');

    if (validateNIC(nic)) {
        var details = extractNICDetails(nic);
        dobInput.value = details.dob;
        genderRadios.forEach(function (radio) {
            if (radio.value === details.gender.toLowerCase()) {
                radio.checked = true;
            }
        });
        var age = calculateAge(new Date(details.dob));
        ageInput.value = age;
    } else {
        alert("Error: Invalid NIC format. Please enter a valid NIC (9 digits followed by V/X or 12 digits).");
    }
});

function validateNIC(nic) {
    // NIC format: either 9 digits followed by a letter (V/v or X/x), or 12 digits
    return /^(\d{9}[vVxX]|\d{12})$/.test(nic);
}

function extractNICDetails(nic) {
    var year, dayList;
    if (nic.length === 10) {
        year = "19" + nic.substr(0, 2);
        dayList = parseInt(nic.substr(2, 3));
    } else if (nic.length === 12) {
        year = nic.substr(0, 4);
        dayList = parseInt(nic.substr(4, 3));
    }
    var dobDetails = getDOB(dayList, year);
    return {
        dob: dobDetails.dob,
        gender: dobDetails.gender
    };
}

function getDOB(dayList, year) {
    var gender = dayList > 500 ? 'Female' : 'Male';
    if (gender === 'Female') dayList -= 500;

    var d_array = [
        { month: '01', days: 31 },
        { month: '02', days: 29 },
        { month: '03', days: 31 },
        { month: '04', days: 30 },
        { month: '05', days: 31 },
        { month: '06', days: 30 },
        { month: '07', days: 31 },
        { month: '08', days: 31 },
        { month: '09', days: 30 },
        { month: '10', days: 31 },
        { month: '11', days: 30 },
        { month: '12', days: 31 }
    ];

    var day = dayList, month = '';
    for (var i = 0; i < d_array.length; i++) {
        if (day > d_array[i].days) {
            day -= d_array[i].days;
        } else {
            month = d_array[i].month;
            break;
        }
    }

    return { dob: year + '-' + month + '-' + day.toString().padStart(2, '0'), gender: gender };
}

function calculateAge(dob) {
    var diff = Date.now() - dob.getTime();
    var ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

document.getElementById('addEmployeeForm').addEventListener('submit', function (event) {
    var nic = document.getElementById('nic').value;
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var phoneno = document.getElementById('phoneno').value;
    var password = document.getElementById('pw').value;
    var confirmPassword = document.getElementById('confirm_password').value;

    var errors = [];

    // NIC validation
    if (!validateNIC(nic)) {
        errors.push("Invalid NIC format. Please enter a valid NIC (9 digits followed by V/X or 12 digits).");
    }

    // Name validation (only letters allowed)
    if (!/^[A-Za-z\s]+$/.test(name)) {
        errors.push("Invalid name format. Name must contain only letters and spaces.");
    }

    // Email validation
    if (!validateEmail(email)) {
        errors.push("Invalid email format. Please enter a valid email address.");
    }

    // Phone number validation (must be 10 digits)
    if (!/^\d{10}$/.test(phoneno)) {
        errors.push("Invalid phone number. Phone number must be exactly 10 digits.");
    }

    // Password validation
    if (password.length < 8) {
        errors.push("Password is too short. It must be at least 8 characters long.");
    }
    
    // Password and confirm password match validation
    if (password !== confirmPassword) {
        errors.push("Passwords do not match.");
    }

    // If there are any errors, show all errors in the alert box and prevent form submission
    if (errors.length > 0) {
        alert("Please fix the following errors:\n\n" + errors.join("\n"));
        event.preventDefault();
    }
});

function validateEmail(email) {
    // Email validation regex pattern
    var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(String(email).toLowerCase());
}
