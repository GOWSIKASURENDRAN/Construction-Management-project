// script.js
document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('#myTable tbody');

    for (let i = 1; i <= 10; i++) {
        const row = document.createElement('tr');
        for (let j = 1; j <= 6; j++) {
            const cell = document.createElement('td');
            cell.textContent = `Row ${i}, Col ${j}`;
            row.appendChild(cell);
        }
        tableBody.appendChild(row);
    }
});
