<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <style>
        footer {
            background: linear-gradient(to right,white,#0b0c10 , #c5c6c7);
            color: #f8f9fa;
            padding: 40px 20px;
            text-align: center;
        }

        footer div {
            max-width: 600px;
            margin: auto;
        }

        footer h3 {
            margin-bottom: 20px;
            font-size: 24px;
            color: lightblue; /* Orange color for heading */
        }

        footer form input[type="email"] {
            padding: 10px;
            width: 70%;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        footer form button {
            padding: 11px 20px;
            background-color: lightblue;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        footer form button:hover {
            background-color: gray; /* Darker orange for hover */
        }

        footer p {
            margin-top: 30px;
            font-size: 14px;
            color: #ccc;
        }

        /* Social Media Icons */
        .social-icons {
            margin-top: 30px;
        }

        .social-icons a {
            margin: 0 10px;
            color: white;
            font-size: 20px;
            transition: color 0.3s ease;
        }

        .social-icons a:hover {
            color: lightblue;
        }

        /* Footer Link Styles */
        footer p a {
            color: lightblue;
            text-decoration: none;
        }

        footer p a:hover {
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 600px) {
            footer form input[type="email"] {
                width: 100%;
                margin-bottom: 10px;
            }

            footer form button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <footer>
        <div>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
            <p>© 2024 Trend Build. All rights reserved. <a href="privacy.html">Privacy Policy</a></p>
        </div>
    </footer>
</body>
</html>
