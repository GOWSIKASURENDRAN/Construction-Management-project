<?php
session_start();
include('config.php'); // db conn

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $username = mysqli_real_escape_string($conn, $username);
    $password = mysqli_real_escape_string($conn, $password);

    // check admin un pw
    $query = "SELECT * FROM tbl_admin WHERE (adminUser='$username' OR adminEmail='$username') AND adminPassword='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['admin'] = $username;
        header("Location: dashboard.php"); // go to admin dashboard
    } else {
        echo "Invalid username or password";
    }
}
?>
