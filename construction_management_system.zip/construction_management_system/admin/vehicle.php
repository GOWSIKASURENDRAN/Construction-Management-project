<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">
</head>
<body>
    <div class="container">
        <br>
        <br>
        <a href="addvehicle.php" class="add-user-btn">+ ADD VEHICLE</a>
        <br>
        <br>
    </div>
    <div class="controls">
        <select id="recordsPerPage">
            <option value="10">10 records per page</option>
            <option value="25">25 records per page</option>
            <option value="50">50 records per page</option>
            <option value="100">100 records per page</option>
        </select>
        <label>Search: <input type="text" id="searchInput" placeholder="Search:"></label>
    </div>
    <table>
        <thead>
            <tr>
                <th>VEHICLE NAME</th>
                <th>MODEL</th>
                <th>YEAR OF MANUFACTURE</th>
                <th>LAST SERVICE DATE</th>
                <th>FUEL TYPE</th>
                <th>IMAGE</th>
                <th>CAPACITY</th>
                <th>MILAGE</th>
                <th>REGISTRATION NUMBER</th>
                <th>RENT STATUS</th>
                <th>ACTION</th>
            </tr>
        </thead>
        <tbody>
        <?php 
            $vehicle_query = mysqli_query($conn, "SELECT * FROM `tbl_vehicle`") or die(mysqli_error($conn));
            if (mysqli_num_rows($vehicle_query) > 0) {
                while ($row = mysqli_fetch_array($vehicle_query)) {
                    if (isset($row['v_id'])) {
                        $v_id = $row['v_id'];
                    }
        ?>
            <tr>
                <td><?php echo $row['v_name']; ?></td>
                <td><?php echo $row['v_model']; ?></td>
                <td><?php echo $row['v_yom']; ?></td>
                <td><?php echo $row['v_lsd']; ?></td>
                <td><?php echo $row['fueltype']; ?></td>
                <td><img src="<?php echo $row['image']; ?>" alt="Vehicle Image" width="100"></td>
                <td><?php echo $row['capacity']; ?></td>
                <td><?php echo $row['milage']; ?></td>
                <td><?php echo $row['regno']; ?></td>
                <td><?php echo $row['rentstatus']; ?></td>
                <td>
                    <a id="<?php echo $v_id; ?>" href="updatevehicle.php?id=<?php echo $v_id; ?>" class="edit-btn">Edit</a>
                    <a id="<?php echo $v_id; ?>" class="delete-btn" data-id="<?php echo $v_id; ?>">Delete</a>
                </td>
            </tr>
        <?php 
                }
            } else {
                echo "<tr><td colspan='12'>No records found</td></tr>";
            }
        ?>
        </tbody>
    </table>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var id = this.getAttribute('data-id');
                if (confirm('Are you sure you want to delete this vehicle?')) {
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'deletevehicle.php?v_id=' + id, true);
                    xhr.onload = function() {
                        if (xhr.status === 200 && xhr.responseText === 'success') {
                            alert('Vehicle deleted successfully.');
                            location.reload();
                        } else {
                            alert('Failed to delete vehicle.');
                        }
                    };
                    xhr.send();
                }
            });
        });
    });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
