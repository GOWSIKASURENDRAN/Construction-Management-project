<?php
include('config.php');

if (isset($_GET['id'])) {
    $nic = $_GET['id'];
    $query = "DELETE FROM `tbl_employee` WHERE `nic` = '$nic'";
    if (mysqli_query($conn, $query)) {
        echo "success";
    } else {
        echo "error";
    }
} else {
    echo "invalid";
}
?>
