<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addcustomer.css">
    <title>Add Customer</title>
</head>
<body>
    <div class="container">
        <form id="addCustomerForm" action="insertcustomer.php" method="POST">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" required>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>

            <label for="phone">Phone No:</label>
            <input type="text" id="phone" name="phone" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>

            <button type="submit">Add Customer</button>
        </form>
    </div>

    <script>
        document.getElementById('addCustomerForm').addEventListener('submit', function(event) {
            var password = document.getElementById('password').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            var name = document.getElementById('name').value;
            var dob = document.getElementById('dob').value;
            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;

            // name validation
            var namePattern = /^[a-zA-Z\s]+$/;
            if (!namePattern.test(name)) {
                alert('Name should not contain numbers.');
                event.preventDefault();
                return;
            }

            // date of Birth validation
            var today = new Date().toISOString().split('T');
            if (dob > today) {
                alert('Date of Birth cannot be in the future.');
                event.preventDefault();
                return;
            }

            // email validation
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert('Please enter a valid email address.');
                event.preventDefault();
                return;
            }

            // phone number validation
            var phonePattern = /^\d+$/;
            if (!phonePattern.test(phone)) {
                alert('Phone number should contain only digits.');
                event.preventDefault();
                return;
            }

            // password confirm validation
            if (password !== confirmPassword) {
                alert('Passwords do not match.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
