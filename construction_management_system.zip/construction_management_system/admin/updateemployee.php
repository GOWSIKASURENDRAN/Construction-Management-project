<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/employeeform.css">
    <script src="js/employeeform.js" defer></script>
    <title>Update Employee</title>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['id'])) {
            $nic = $_GET['id'];
            $query = "SELECT * FROM `tbl_employee` WHERE `nic` = '$nic'";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
        ?>
        <form id="updateEmployeeForm" action="saveupdateemployee.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="nic" value="<?php echo $row['nic']; ?>">

            <h1>Update Employee Details</h1>

            <div class="inputgroup">
                <label for="nic">NIC:</label>
                <input type="text" id="nic" name="nic" value="<?php echo $row['nic']; ?>" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" required pattern="[A-Za-z\s]+" title="Name must contain only letters.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="gender">Gender:</label>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="male" name="gender" value="male" <?php if($row['gender'] == 'male') echo 'checked'; ?>>
                        <label for="male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="female" name="gender" value="female" <?php if($row['gender'] == 'female') echo 'checked'; ?>>
                        <label for="female">Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="other" name="gender" value="other" <?php if($row['gender'] == 'other') echo 'checked'; ?>>
                        <label for="other">Prefer not to say</label>
                    </div>
                </div>
            </div>

            <div class="inputgroup">
                <label for="dateofjoin">Date of Joining:</label>
                <input type="date" id="dateofjoin" name="dateofjoin" value="<?php echo $row['doj']; ?>" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" value="<?php echo $row['dob']; ?>" readonly required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="jobtitle">Job Title:</label>
                <input type="text" id="jobtitle" name="jobtitle" value="<?php echo $row['jobtitle']; ?>" required pattern="[A-Za-z\s]+" title="Job title must contain only letters.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="category">Employee Category:</label>
                <select name="empcat" id="category">
                    <option value="Fulltime" <?php if($row['empcat'] == 'Fulltime') echo 'selected'; ?>>Fulltime</option>
                    <option value="Parttime" <?php if($row['empcat'] == 'Parttime') echo 'selected'; ?>>Parttime</option>
                </select>
            </div>

            <div class="inputgroup">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $row['Email']; ?>" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="phoneno">Phone No:</label>
                <input type="text" id="phoneno" name="phoneno" value="<?php echo $row['phoneno']; ?>" required pattern="\d{10}" title="Phone number must be 10 digits.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="hirestatus">Hire Status:</label>
                <select name="hirestatus" id="hirestatus">
                    <option value="Available" <?php if($row['hirestatus'] == 'Available') echo 'selected'; ?>>Available</option>
                    <option value="NotAvailable" <?php if($row['hirestatus'] == 'NotAvailable') echo 'selected'; ?>>Not Available</option>
                </select>
            </div>

            <div class="inputgroup">
                <label for="hourssalary">Hourly Salary:</label>
                <input type="number" id="hourssalary" name="hourssalary" value="<?php echo $row['hourssalary']; ?>" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="age">Age:</label>
                <input type="number" id="age" name="age" value="<?php echo $row['age']; ?>" readonly required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" value="<?php echo $row['address']; ?>" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="pw">Password (Leave blank if not changing):</label>
                <input type="password" id="pw" name="pw">
            </div>

            <div class="inputgroup">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password">
            </div>

            <button id="button" type="submit">Update</button>
        </form>
        <?php
            } else {
                echo "<p>Employee not found.</p>";
            }
        } else {
            echo "<p>Invalid request.</p>";
        }
        ?>
    </div>

    <script>
        document.getElementById('nic').addEventListener('input', function() {
            var nic = this.value;
            var dobInput = document.getElementById('dob');
            var genderRadios = document.getElementsByName('gender');
            var ageInput = document.getElementById('age');

            if (validateNIC(nic)) {
                var details = extractNICDetails(nic);
                dobInput.value = details.dob;
                genderRadios.forEach(function(radio) {
                    if (radio.value === details.gender.toLowerCase()) {
                        radio.checked = true;
                    }
                });
                var age = calculateAge(new Date(details.dob));
                ageInput.value = age;
            }
        });

        function validateNIC(nic) {
            return /^(\d{9}[vVxX]|\d{12})$/.test(nic);
        }

        function extractNICDetails(nic) {
            var year, dayList;
            if (nic.length === 10) {
                year = "19" + nic.substr(0, 2);
                dayList = parseInt(nic.substr(2, 3));
            } else if (nic.length === 12) {
                year = nic.substr(0, 4);
                dayList = parseInt(nic.substr(4, 3));
            }
            var dobDetails = getDOB(dayList, year);
            return {
                dob: dobDetails.dob,
                gender: dobDetails.gender
            };
        }

        function getDOB(dayList, year) {
            var gender = dayList > 500 ? 'Female' : 'Male';
            if (gender === 'Female') dayList -= 500;

            var d_array = [
                { month: '01', days: 31 },
                { month: '02', days: 29 },
                { month: '03', days: 31 },
                { month: '04', days: 30 },
                { month: '05', days: 31 },
                { month: '06', days: 30 },
                { month: '07', days: 31 },
                { month: '08', days: 31 },
                { month: '09', days: 30 },
                { month: '10', days: 31 },
                { month: '11', days: 30 },
                { month: '12', days: 31 }
            ];

            var day = dayList, month = '';
            for (var i = 0; i < d_array.length; i++) {
                if (day > d_array[i].days) {
                    day -= d_array[i].days;
                } else {
                    month = d_array[i].month;
                    break;
                }
            }

            return { dob: year + '-' + month + '-' + day.toString().padStart(2, '0'), gender: gender };
        }

        function calculateAge(dob) {
            var diff = Date.now() - dob.getTime();
            var ageDate = new Date(diff);
            return Math.abs(ageDate.getUTCFullYear() - 1970);
        }

        document.getElementById('updateEmployeeForm').addEventListener('submit', function(event) {
            var password = document.getElementById('pw').value;
            var confirmPassword = document.getElementById('confirm_password').value;

            if (password !== '' && password !== confirmPassword) {
                alert('Passwords do not match.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
