<?php include('config.php'); ?>
<?php include('inc/header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Table</title>
    <link rel="stylesheet" href="css/usertable.css">
    <link rel="stylesheet" href="css/popupform.css">
    <script src="js/formValidation.js"></script>
</head>
<body>
    <div class="container">
        <button id="openFormBtn" class="add-user-btn">+ ADD USER</button>
        <div id="overlay" class="overlay"></div>
        <div id="popupForm" class="form-popup">
            <form class="form-container" method="POST" action="">
                <h2>Add User</h2>

                <label for="adminName"><b>NAME</b></label>
                <input type="text" placeholder="Enter Name" name="adminName" id="adminName" required>

                <label for="adminUser"><b>USERNAME</b></label>
                <input type="text" placeholder="Enter Username" name="adminUser" id="adminUser" required>

                <label for="adminEmail"><b>EMAIL</b></label>
                <input type="email" placeholder="Enter Email" name="adminEmail" id="adminEmail" required>

                <label for="level"><b>TYPE</b></label>
                <input type="radio" value="admin" name="level" required> Admin
                <input type="radio" value="staff" name="level" required> Staff <br><br>

                <label for="adminPassword"><b>PASSWORD</b></label>
                <input type="password" placeholder="Enter Password (update new user)" name="adminPassword" id="adminPassword">

                <button type="submit" class="btn">Save</button>
                <button type="button" class="btn cancel" id="closeFormBtn">Close</button>
            </form>
        </div>

        <div class="controls">
            <select id="recordsPerPage">
                <option value="10">10 records per page</option>
                <option value="25">25 records per page</option>
                <option value="50">50 records per page</option>
                <option value="100">100 records per page</option>
            </select>
            <label>Search: <input type="text" id="searchInput" placeholder="Search"></label>
        </div>

        <table style="width: 100%;">
            <thead>
                <tr>
                    <th>NAME</th>
                    <th>USERNAME</th>
                    <th>EMAIL</th>
                    <th>PASSWORD</th>
                    <th>TYPE</th>
                    <th>ACTION</th>
                </tr>
            </thead>
            <tbody>
            <?php 
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $name = $_POST['adminName'];
                    $user = $_POST['adminUser'];
                    $email = $_POST['adminEmail'];
                    $type = $_POST['level'];

                    // Check if the form is for editing or adding a new user
                    if (isset($_POST['id'])) {
                        // Edit user
                        $id = $_POST['id'];
                        $password = !empty($_POST['adminPassword']) ? $_POST['adminPassword'] : ''; // Get password if provided

                        // Update query
                        if ($password) {
                            $query = "UPDATE tbl_admin SET adminUser='$user', adminPassword='$password', adminName='$name', adminEmail='$email', level='$type' WHERE adminId=$id";
                        } else {
                            $query = "UPDATE tbl_admin SET adminUser='$user', adminName='$name', adminEmail='$email', level='$type' WHERE adminId=$id";
                        }

                        if (mysqli_query($conn, $query)) {
                            echo "<script>alert('Updated successfully');</script>";
                        } else {
                            echo "Error: " . $query . "<br>" . mysqli_error($conn);
                        }
                    } else {
                        // New user
                        $password = $_POST['adminPassword'];
                        $query = "INSERT INTO tbl_admin (adminName, adminUser, adminEmail, adminPassword, level) VALUES ('$name', '$user', '$email', '$password', '$type')";
                        if (mysqli_query($conn, $query)) {
                            echo "<script>alert('Successfully created');</script>";
                        } else {
                            echo "Error: " . $query . "<br>" . mysqli_error($conn);
                        }
                    }
                }

                // Fetch all users from the database
                $user_query = mysqli_query($conn, "SELECT * FROM `tbl_admin`") or die(mysqli_error($conn));
                if (mysqli_num_rows($user_query) > 0) {
                    while ($row = mysqli_fetch_array($user_query)) {
                        if (isset($row['adminId'])) {
                            $id = $row['adminId'];
            ?>
                <tr>
                    <td><?php echo $row['adminName']; ?></td>
                    <td><?php echo $row['adminUser']; ?></td>
                    <td><?php echo $row['adminEmail']; ?></td>
                    <td>******</td> <!-- Hide password -->
                    <td><?php echo $row['level']; ?></td>
                    <td>
                        <button id="<?php echo $id; ?>" class="edit-btn" onclick="editUser(<?php echo $id; ?>)">Edit</button>
                        <button id="<?php echo $id; ?>" class="delete-btn" data-id="<?php echo $id; ?>">Delete</button>
                    </td>
                </tr>
            <?php 
                        }
                    }
                } else {
                    echo "<tr><td colspan='6'>No records found</td></tr>";
                }
            ?>
            </tbody>
        </table>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var openFormBtn = document.getElementById('openFormBtn');
            var closeFormBtn = document.getElementById('closeFormBtn');
            var popupForm = document.getElementById('popupForm');
            var overlay = document.getElementById('overlay');

            openFormBtn.addEventListener('click', function() {
                popupForm.style.display = 'block';
                overlay.style.display = 'block';
            });

            closeFormBtn.addEventListener('click', function() {
                popupForm.style.display = 'none';
                overlay.style.display = 'none';
            });

            window.addEventListener('click', function(event) {
                if (event.target == overlay) {
                    popupForm.style.display = 'none';
                    overlay.style.display = 'none';
                }
            });

            var deleteButtons = document.querySelectorAll('.delete-btn');
            deleteButtons.forEach(function(button) {
                button.addEventListener('click', function() {
                    var id = this.getAttribute('data-id');
                    if (confirm('Are you sure you want to delete this user?')) {
                        var xhr = new XMLHttpRequest();
                        xhr.open('POST', 'delete_user.php', true);
                        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                        xhr.onload = function() {
                            if (xhr.status === 200 && xhr.responseText === 'success') {
                                alert('User deleted successfully.');
                                location.reload();
                            } else {
                                alert('Failed to delete user.');
                            }
                        };
                        xhr.send('id=' + id);
                    }
                });
            });
        });

        function editUser(id) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'get_user.php?id=' + id, true);
            xhr.onload = function() {
                if (xhr.status === 200) {
                    var user = JSON.parse(xhr.responseText);
                    document.querySelector('input[name="adminUser"]').value = user.adminUser;
                    document.querySelector('input[name="adminPassword"]').value = '';  // Clear the password field
                    document.querySelector('input[name="adminPassword"]').placeholder = 'reenter password';
                    document.querySelector('input[name="adminName"]').value = user.adminName;
                    document.querySelector('input[name="adminEmail"]').value = user.adminEmail;
                    document.querySelector('input[name="level"][value="' + user.level + '"]').checked = true;  // Set the correct type radio button
                    document.querySelector('form').action = '';
                    document.querySelector('form').insertAdjacentHTML('beforeend', '<input type="hidden" name="id" value="' + user.adminId + '">');
                    popupForm.style.display = 'block';
                    overlay.style.display = 'block';
                }
            };
            xhr.send();
        }
    </script>
</body>
</html>

<?php include('inc/footer.php'); ?>
