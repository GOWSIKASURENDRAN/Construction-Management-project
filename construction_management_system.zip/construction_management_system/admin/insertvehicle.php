<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $v_name = $_POST['v_name'];
    $v_model = $_POST['v_model'];
    $v_yom = $_POST['v_yom'];
    $v_lsd = $_POST['v_lsd'];
    $fueltype = $_POST['fueltype'];
    $capacity = $_POST['capacity'];
    $milage = $_POST['milage'];
    $regno = $_POST['regno'];
    $rentstatus = $_POST['rentstatus'];

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check === false) {
        echo "File is not an image.";
        exit;
    }

    // Check file size (5MB max)
    if ($_FILES["image"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        exit;
    }

    // Allow certain file formats
    $allowed_types = array("jpg", "jpeg", "png", "gif");
    if (!in_array($imageFileType, $allowed_types)) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        exit;
    }

    // Check if file already exists
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        exit;
    }

    // Try to upload file
    if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        echo "Sorry, there was an error uploading your file.";
        exit;
    }

    // Insert data into database
    $query = "INSERT INTO `tbl_vehicle` (`v_name`, `v_model`, `v_yom`, `v_lsd`, `fueltype`, `image`, `capacity`, `milage`, `regno`, `rentstatus`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssssssss", $v_name, $v_model, $v_yom, $v_lsd, $fueltype, $target_file, $capacity, $milage, $regno, $rentstatus);

    if ($stmt->execute()) {
        header('Location: vehicle.php');
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
