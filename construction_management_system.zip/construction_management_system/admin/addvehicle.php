<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addcustomer.css">
    <title>Add Vehicle</title>
</head>
<body>
    <div class="container">
        <form id="addVehicleForm" action="insertvehicle.php" method="POST" enctype="multipart/form-data">
            <label for="v_name">Vehicle Name:</label>
            <input type="text" id="v_name" name="v_name" required>

            <label for="v_model">Model:</label>
            <input type="text" id="v_model" name="v_model" required>

            <label for="v_yom">Year of Manufacture:</label>
            <input type="text" id="v_yom" name="v_yom" required>

            <label for="v_lsd">Last Service Date:</label>
            <input type="date" id="v_lsd" name="v_lsd" required>

            <label for="fueltype">Fuel Type:
            <select id="fueltype" class="option" name="fuel-type">
             <option value="petrol">Petrol</option>
             <option value="Diesel">Diesel</option>
             </select>
             </label>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image" required>

            <label for="capacity">Capacity:</label>
            <input type="text" id="capacity" name="capacity" required>

            <label for="milage">Milage:</label>
            <input type="text" id="milage" name="milage" required>

            <label for="regno">Registration Number:</label>
            <input type="text" id="regno" name="regno" required>

            <label for="rentstatus">Rent Status:</label>
            <select id="rentstatus" class="option" name="rentstatus">
             <option value="Available">Available</option>
             <option value="NotAvalable">Not Available</option>
             </select>

            <button type="submit">Add Vehicle</button>
        </form>
    </div>

    <script>
        document.getElementById('addVehicleForm').addEventListener('submit', function(event) {
            var vName = document.getElementById('v_name').value;
            var vYom = document.getElementById('v_yom').value;
            var vLsd = document.getElementById('v_lsd').value;
            var milage = document.getElementById('milage').value;

            // Vehicle name validation: text only
            var namePattern = /^[a-zA-Z\s]+$/;
            if (!namePattern.test(vName)) {
                alert('Vehicle name should contain only letters.');
                event.preventDefault();
                return;
            }

            // Year of Manufacture validation: no future years
            var currentYear = new Date().getFullYear();
            if (vYom > currentYear) {
                alert('Year of Manufacture cannot be in the future.');
                event.preventDefault();
                return;
            }

            // Last Service Date validation: must be after Year of Manufacture
            if (new Date(vLsd).getFullYear() < vYom) {
                alert('Last Service Date cannot be before the Year of Manufacture.');
                event.preventDefault();
                return;
            }

            // Milage validation: only numbers
            var milagePattern = /^\d+$/;
            if (!milagePattern.test(milage)) {
                alert('Milage should contain only numbers.');
                event.preventDefault();
                return;
            }
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>