<?php include('inc/header.php'); ?>
<?php
include('dbcon/config.php');
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM tbl_contact WHERE id = $id";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $query = "UPDATE tbl_contact SET status = '$status' WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        header('Location: admin_contact.php');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Edit Contact Message - Trend-Build</title>
    <link rel="stylesheet" href="css/admin_style.css">
</head>
<body>
    <section>
        <h1>Edit Contact Message</h1>
        <form action="edit_contact.php" method="post">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                <option value="Resolved" <?php if ($row['status'] == 'Resolved') echo 'selected'; ?>>Resolved</option>
            </select>
            <input type="submit" value="Update">
        </form>
    </section>
</body>
</html>
