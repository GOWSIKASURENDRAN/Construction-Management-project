<?php
include('config.php');

if (isset($_GET['v_id'])) {
    $v_id = intval($_GET['v_id']);
    $query = "DELETE FROM `tbl_vehicle` WHERE `v_id` = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $v_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "success";
    } else {
        echo "error: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
} else {
    echo "invalid";
}
?>
