<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "INSERT INTO tbl_customer (name, dob, address, phone, email, pass) VALUES ('$name', '$dob', '$address', '$phone', '$email', '$password')";
    if (mysqli_query($conn, $query)) {
        header('Location: customer.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>