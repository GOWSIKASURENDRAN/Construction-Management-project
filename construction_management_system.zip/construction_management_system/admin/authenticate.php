<?php
session_start();
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usernameOrEmail = $_POST['username'];
    $password = $_POST['password'];

    $query = "SELECT * FROM `tbl_admin` WHERE `adminUser` = '$usernameOrEmail' OR `adminEmail` = '$usernameOrEmail'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($password, $row['adminPassword'])) {
            $_SESSION['admin'] = $row['adminUser'];
            header('Location: dashboard.php');
            die();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found.";
    }
}
?>
