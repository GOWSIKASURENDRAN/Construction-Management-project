<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addcustomer.css">
    <title>Add Product</title>
</head>
<body>
    <div class="container">
        <form id="addProductForm" action="insertproduct.php" method="POST" enctype="multipart/form-data">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" required>

            <label for="body">Description:</label>
            <textarea id="body" name="body" required></textarea>

            <label for="price">Price:</label>
            <input type="number" step="0.01" id="price" name="price" required>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required>
            <img id="imagePreview" src="#" alt="Image Preview" style="display:none; max-width: 100%; height: auto; margin-top: 10px;">

            <label for="type">Type:</label>
            <input type="text" id="type" name="type" required>

            <button type="submit">Add Product</button>
        </form>
    </div>

    <script>
        document.getElementById('price').addEventListener('input', function(event) {
            var value = event.target.value;
            if (!/^\d*\.?\d*$/.test(value)) {
                event.target.value = value.slice(0, -1);
            }
        });

        document.getElementById('image').addEventListener('change', function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var imagePreview = document.getElementById('imagePreview');
                imagePreview.src = reader.result;
                imagePreview.style.display = 'block';
            }
            reader.readAsDataURL(event.target.files);
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
