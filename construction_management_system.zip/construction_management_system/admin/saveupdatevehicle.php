<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $v_id = $_POST['v_id'];
    $v_name = $_POST['v_name'];
    $v_model = $_POST['v_model'];
    $v_yom = $_POST['v_yom'];
    $v_lsd = $_POST['v_lsd'];
    $fueltype = $_POST['fueltype'];
    $image = $_POST['image'];
    $capacity = $_POST['capacity'];
    $milage = $_POST['milage'];
    $regno = $_POST['regno'];
    $rentstatus = $_POST['rentstatus'];

    $query = "UPDATE `tbl_vehicle` SET `v_name`='$v_name', `v_model`='$v_model', `v_yom`='$v_yom', `v_lsd`='$v_lsd', `fueltype`='$fueltype', `image`='$image', `capacity`='$capacity', `milage`='$milage', `regno`='$regno', `rentstatus`='$rentstatus' WHERE `v_id`=$v_id";
    if (mysqli_query($conn, $query)) {
        header('Location: vehicle.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
