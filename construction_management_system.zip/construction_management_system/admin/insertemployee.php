<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nic = $_POST['nic'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $jobtitle = $_POST['jobtitle'];
    $empcat = $_POST['empcat'];
    $email = $_POST['email'];
    $phoneno = $_POST['phoneno'];
    $hirestatus = $_POST['hirestatus'];
    $hourssalary = $_POST['hourssalary'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $password = password_hash($_POST['pw'], PASSWORD_DEFAULT);

    $query = "INSERT INTO `tbl_employee` (`nic`, `name`, `gender`, `dob`, `jobtitle`, `empcat`, `email`, `phoneno`, `hirestatus`, `hourssalary`, `age`, `address`, `pw`) VALUES ('$nic', '$name', '$gender', '$dob', '$jobtitle', '$empcat', '$email', '$phoneno', '$hirestatus', '$hourssalary', '$age', '$address', '$password')";
    if (mysqli_query($conn, $query)) {
        header('Location: employee.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
