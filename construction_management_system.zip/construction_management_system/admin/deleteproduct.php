<?php
include('config.php');

if (isset($_GET['id'])) {
    $productId = intval($_GET['id']);
    $query = "DELETE FROM `tbl_product` WHERE `productId` = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $productId);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "success";
    } else {
        echo "error: " . mysqli_error($conn);
    }
    mysqli_stmt_close($stmt);
} else {
    echo "invalid";
}
?>
