<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addcustomer.css">
    <title>Update Vehicle</title>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['id'])) {
            $v_id = intval($_GET['id']);
            $query = "SELECT * FROM `tbl_vehicle` WHERE `v_id` = $v_id";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
        ?>
        <form id="updateVehicleForm" action="saveupdatevehicle.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="v_id" value="<?php echo $row['v_id']; ?>">

            <label for="v_name">Vehicle Name:</label>
            <input type="text" id="v_name" name="v_name" value="<?php echo $row['v_name']; ?>" required>

            <label for="v_model">Model:</label>
            <input type="text" id="v_model" name="v_model" value="<?php echo $row['v_model']; ?>" required>

            <label for="v_yom">Year of Manufacture:</label>
            <input type="text" id="v_yom" name="v_yom" value="<?php echo $row['v_yom']; ?>" required>

            <label for="v_lsd">Last Service Date:</label>
            <input type="date" id="v_lsd" name="v_lsd" value="<?php echo $row['v_lsd']; ?>" required>

            <label for="fueltype">Fuel Type:</label>
            <input type="text" id="fueltype" name="fueltype" value="<?php echo $row['fueltype']; ?>" required>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image" accept="image/*">
            <img id="imagePreview" src="<?php echo $row['image']; ?>" alt="Image Preview" style="max-width: 100%; height: auto; margin-top: 10px;">

            <label for="capacity">Capacity:</label>
            <input type="text" id="capacity" name="capacity" value="<?php echo $row['capacity']; ?>" required>

            <label for="milage">Milage:</label>
            <input type="text" id="milage" name="milage" value="<?php echo $row['milage']; ?>" required>

            <label for="regno">Registration Number:</label>
            <input type="text" id="regno" name="regno" value="<?php echo $row['regno']; ?>" required>

            <label for="rentstatus">Rent Status:</label>
            <input type="text" id="rentstatus" name="rentstatus" value="<?php echo $row['rentstatus']; ?>" required>

            <button type="submit">Update Vehicle</button>
        </form>
        <?php
            } else {
                echo "<p>Vehicle not found.</p>";
            }
        } else {
            echo "<p>Invalid request.</p>";
        }
        ?>
    </div>

    <script>
        document.getElementById('updateVehicleForm').addEventListener('submit', function(event) {
            var vName = document.getElementById('v_name').value;
            var vYom = document.getElementById('v_yom').value;
            var vLsd = document.getElementById('v_lsd').value;
            var milage = document.getElementById('milage').value;

            // Vehicle name validation: text only
            var namePattern = /^[a-zA-Z\s]+$/;
            if (!namePattern.test(vName)) {
                alert('Vehicle name should contain only letters.');
                event.preventDefault();
                return;
            }

            // Year of Manufacture validation: no future years
            var currentYear = new Date().getFullYear();
            if (vYom > currentYear) {
                alert('Year of Manufacture cannot be in the future.');
                event.preventDefault();
                return;
            }

            // Last Service Date validation: must be after Year of Manufacture
            if (new Date(vLsd).getFullYear() < vYom) {
                alert('Last Service Date cannot be before the Year of Manufacture.');
                event.preventDefault();
                return;
            }

            // Milage validation: only numbers
            var milagePattern = /^\d+$/;
            if (!milagePattern.test(milage)) {
                alert('Milage should contain only numbers.');
                event.preventDefault();
                return;
            }
        });

        document.getElementById('image').addEventListener('change', function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var imagePreview = document.getElementById('imagePreview');
                imagePreview.src = reader.result;
                imagePreview.style.display = 'block';
            }
            reader.readAsDataURL(event.target.files);
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
