<?php include('inc/header.php'); ?>
<?php
include('config.php');
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Admin Panel - Contact Us Messages</title>
    <link rel="stylesheet" href="css/table.css">
</head>
<body>
<br>
        <br>
        <br>
        <br>
        <br>
    <section>
                <h1 style="font-size: 2em; color: #333; text-align: center; margin-bottom: 20px;">Contact Us Messages</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
            <?php
            $query = "SELECT * FROM tbl_contact";
            $result = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['message'] . "</td>";
                echo "<td>" . $row['status'] . "</td>";
                echo "<td>" . $row['date'] . "</td>";
                echo "<td>
                        <a href='edit_contact.php?id=" . $row['id'] . "'>Edit</a> | 
                        <a href='delete_contact.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this message?\")'>Delete</a>
                      </td>";
                echo "</tr>";
            }
            ?>
        </table>
    </section>
</body>
</html>
<?php include('inc/footer.php'); ?>
