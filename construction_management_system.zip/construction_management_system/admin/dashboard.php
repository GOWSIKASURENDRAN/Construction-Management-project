<?php
include('inc/header.php');
?>
<h2>Welcome to the Admin Dashboard</h2>
<p>Use the navigation menu to manage projects, employees, clients, and tasks.</p>
<?php include('inc/footer.php'); ?>
