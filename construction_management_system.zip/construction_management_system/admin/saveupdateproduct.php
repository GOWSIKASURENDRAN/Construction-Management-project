<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productId = $_POST['productId'];
    $productName = $_POST['productName'];
    $body = $_POST['body'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $type = $_POST['type'];

    $query = "UPDATE `tbl_product` SET `productName`='$productName', `body`='$body', `price`='$price', `image`='$image', `type`='$type' WHERE `productId`=$productId";
    if (mysqli_query($conn, $query)) {
        header('Location: product.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
