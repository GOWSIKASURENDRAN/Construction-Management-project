<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $dateofjoin = $_POST['dateofjoin'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $query = "UPDATE tbl_customer SET name='$name', dob='$dob', address='$address', dateofjoin='$dateofjoin', phone='$phone', email='$email', pass='$password' WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        header('Location: customer.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>