<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addcustomer.css">
    <title>Update Product</title>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['id'])) {
            $productId = intval($_GET['id']);
            $query = "SELECT * FROM `tbl_product` WHERE `productId` = $productId";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
        ?>
        <form id="updateProductForm" action="saveupdateproduct.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="productId" value="<?php echo $row['productId']; ?>">

            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" value="<?php echo $row['productName']; ?>" required>

            <label for="body">Description:</label>
            <textarea id="body" name="body" required><?php echo $row['body']; ?></textarea>

            <label for="price">Price:</label>
            <input type="number" step="0.01" id="price" name="price" value="<?php echo $row['price']; ?>" required>

            <label for="image">Image:</label>
            <input type="file" id="image" name="image" accept="image/*">
            <img id="imagePreview" src="<?php echo $row['image']; ?>" alt="Image Preview" style="max-width: 100%; height: auto; margin-top: 10px;">

            <label for="type">Type:</label>
            <input type="text" id="type" name="type" value="<?php echo $row['type']; ?>" required>

            <button type="submit">Update Product</button>
        </form>
        <?php
            } else {
                echo "<p>Product not found.</p>";
            }
        } else {
            echo "<p>Invalid request.</p>";
        }
        ?>
    </div>

    <script>
        document.getElementById('price').addEventListener('input', function(event) {
            var value = event.target.value;
            if (!/^\d*\.?\d*$/.test(value)) {
                event.target.value = value.slice(0, -1);
            }
        });

        document.getElementById('image').addEventListener('change', function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var imagePreview = document.getElementById('imagePreview');
                imagePreview.src = reader.result;
                imagePreview.style.display = 'block';
            }
            reader.readAsDataURL(event.target.files);
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
