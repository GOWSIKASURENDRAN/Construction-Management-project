<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">
    <title>Employee List</title>
</head>
<body>
    <div class="container">
        <br>
        <br>
        <a href="addemployee.php" class="add-user-btn">+ ADD EMPLOYEE</a>
        <br>
        <br>
    </div>
    <div class="controls">
        <select id="recordsPerPage">
            <option value="10">10 records per page</option>
            <option value="25">25 records per page</option>
            <option value="50">50 records per page</option>
            <option value="100">100 records per page</option>
        </select>
        <label>Search: <input type="text" id="searchInput" placeholder="Search:"></label>
    </div>
    <table>
        <thead>
            <tr>
                <th>NIC</th>
                <th>NAME</th>
                <th>GENDER</th>
                <th>DATE OF JOINING</th>
                <th>DATE OF BIRTH</th>
                <th>JOB TITLE</th>
                <th>EMPLOYEE CATEGORY</th>
                <th>EMAIL</th>
                <th>PHONE NO</th>
                <th>HIRE STATUS</th>
                <th>HOURLY SALARY</th>
                <th>AGE</th>
                <th>ADDRESS</th>
                <th>ACTION</th>
            </tr>
        </thead>
        <tbody>
        <?php 
            $employee_query = mysqli_query($conn, "SELECT * FROM `tbl_employee`") or die(mysqli_error($conn));
            if (mysqli_num_rows($employee_query) > 0) {
                while ($row = mysqli_fetch_array($employee_query)) {
                    $nic = $row['nic'];
        ?>
            <tr>
                <td><?php echo $row['nic']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['gender']; ?></td>
                <td><?php echo $row['doj']; ?></td>
                <td><?php echo $row['dob']; ?></td>
                <td><?php echo $row['jobtitle']; ?></td>
                <td><?php echo $row['empcat']; ?></td>
                <td><?php echo $row['Email']; ?></td>
                <td><?php echo $row['phoneno']; ?></td>
                <td><?php echo $row['hirestatus']; ?></td>
                <td><?php echo $row['hourssalary']; ?></td>
                <td><?php echo $row['age']; ?></td>
                <td><?php echo $row['address']; ?></td>
                <td>
                    <a id="<?php echo $nic; ?>" href="updateemployee.php?id=<?php echo $nic; ?>" class="edit-btn">Edit</a>
                    <a id="<?php echo $nic; ?>" class="delete-btn" data-id="<?php echo $nic; ?>">Delete</a>
                </td>
            </tr>
        <?php 
                }
            } else {
                echo "<tr><td colspan='14'>No records found</td></tr>";
            }
        ?>
        </tbody>
    </table>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var id = this.getAttribute('data-id');
                if (confirm('Are you sure you want to delete this employee?')) {
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'deleteemployee.php?id=' + id, true);
                    xhr.onload = function() {
                        if (xhr.status === 200 && xhr.responseText === 'success') {
                            alert('Employee deleted successfully.');
                            location.reload();
                        } else {
                            alert('Failed to delete employee.');
                        }
                    };
                    xhr.send();
                }
            });
        });
    });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
