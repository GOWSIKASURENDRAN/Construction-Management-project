
<?php
include('dbcon/config.php');
session_start();

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM tbl_contact WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        header('Location: admin_contact.php');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
