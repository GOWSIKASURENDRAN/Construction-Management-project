<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $productName = $_POST['productName'];
    $body = $_POST['body'];
    $price = $_POST['price'];
    $image = $_POST['image'];
    $type = $_POST['type'];

    $query = "INSERT INTO `tbl_product` (`productName`, `body`, `price`, `image`, `type`) VALUES ('$productName', '$body', '$price', '$image', '$type')";
    if (mysqli_query($conn, $query)) {
        header('Location: product.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
