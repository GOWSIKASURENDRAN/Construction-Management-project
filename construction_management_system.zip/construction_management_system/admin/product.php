<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/table.css">
    <title>Product List</title>
</head>
<body>
    <div class="container">
        <br>
        <br>
        <a href="addproduct.php" class="add-user-btn">+ ADD PRODUCT</a>
        <br>
        <br>
    </div>
    <div class="controls">
        <select id="recordsPerPage">
            <option value="10">10 records per page</option>
            <option value="25">25 records per page</option>
            <option value="50">50 records per page</option>
            <option value="100">100 records per page</option>
        </select>
        <label>Search: <input type="text" id="searchInput" placeholder="Search:"></label>
    </div>
    <table>
        <thead>
            <tr>
                <th>PRODUCT NAME</th>
                <th>DESCRIPTION</th>
                <th>PRICE</th>
                <th>IMAGE</th>
                <th>TYPE</th>
                <th>ACTION</th>
            </tr>
        </thead>
        <tbody>
        <?php 
            $product_query = mysqli_query($conn, "SELECT * FROM `tbl_product`") or die(mysqli_error($conn));
            if (mysqli_num_rows($product_query) > 0) {
                while ($row = mysqli_fetch_array($product_query)) {
                    $productId = $row['productId'];
        ?>
            <tr>
                <td><?php echo $row['productName']; ?></td>
                <td><?php echo $row['body']; ?></td>
                <td><?php echo $row['price']; ?></td>
                <td><img src="<?php echo $row['image']; ?>" alt="Product Image" width="100"></td>
                <td><?php echo $row['type']; ?></td>
                <td>
                    <a id="<?php echo $productId; ?>" href="updateproduct.php?id=<?php echo $productId; ?>" class="edit-btn">Edit</a>
                    <a id="<?php echo $productId; ?>" class="delete-btn" data-id="<?php echo $productId; ?>">Delete</a>
                </td>
            </tr>
        <?php 
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>";
            }
        ?>
        </tbody>
    </table>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var deleteButtons = document.querySelectorAll('.delete-btn');
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                var id = this.getAttribute('data-id');
                if (confirm('Are you sure you want to delete this product?')) {
                    var xhr = new XMLHttpRequest();
                    xhr.open('GET', 'deleteproduct.php?id=' + id, true);
                    xhr.onload = function() {
                        if (xhr.status === 200 && xhr.responseText === 'success') {
                            alert('Product deleted successfully.');
                            location.reload();
                        } else {
                            alert('Failed to delete product.');
                        }
                    };
                    xhr.send();
                }
            });
        });
    });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
