<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/addcustomer.css">
    <title>Update Customer</title>
</head>
<body>
    <div class="container">
        <?php
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $query = "SELECT * FROM `tbl_customer` WHERE `id` = $id";
            $result = mysqli_query($conn, $query);
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
        ?>
        <form id="updateCustomerForm" action="saveupdatecustomer.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" value="<?php echo $row['dob']; ?>" required>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<?php echo $row['address']; ?>" required>

            <label for="phone">Phone No:</label>
            <input type="text" id="phone" name="phone" value="<?php echo $row['phone']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $row['email']; ?>" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password">

            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password">

            <button type="submit">Update Customer</button>
        </form>
        <?php
            } else {
                echo "<p>Customer not found.</p>";
            }
        } else {
            echo "<p>Invalid request.</p>";
        }
        ?>
    </div>
    <script>
        document.getElementById('updateCustomerForm').addEventListener('submit', function(event) {
            var password = document.getElementById('password').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            var name = document.getElementById('name').value;
            var dob = document.getElementById('dob').value;
            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;

            // Name validation
            var namePattern = /^[a-zA-Z\s]+$/;
            if (!namePattern.test(name)) {
                alert('Name should not contain numbers.');
                event.preventDefault();
                return;
            }

            // Date of Birth validation
            var today = new Date().toISOString().split('T');
            if (dob > today) {
                alert('Date of Birth cannot be in the future.');
                event.preventDefault();
                return;
            }

            // Email validation
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert('Please enter a valid email address.');
                event.preventDefault();
                return;
            }

            // Phone number validation
            var phonePattern = /^\d+$/;
            if (!phonePattern.test(phone)) {
                alert('Phone number should contain only digits.');
                event.preventDefault();
                return;
            }

            // Password confirmation validation
            if (password !== confirmPassword) {
                alert('Passwords do not match.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
