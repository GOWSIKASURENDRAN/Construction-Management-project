<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nic = $_POST['nic'];
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $doj = $_POST['doj'];
    $dob = $_POST['dob'];
    $jobtitle = $_POST['jobtitle'];
    $empcat = $_POST['empcat'];
    $email = $_POST['email'];
    $phoneno = $_POST['phoneno'];
    $hirestatus = $_POST['hirestatus'];
    $hourssalary = $_POST['hourssalary'];
    $age = $_POST['age'];
    $address = $_POST['address'];
    $password = password_hash($_POST['pw'], PASSWORD_DEFAULT);

    $query = "UPDATE `tbl_employee` SET `name`='$name', `gender`='$gender', `doj`='$doj', `dob`='$dob', `jobtitle`='$jobtitle', `empcat`='$empcat', `Email`='$email', `phoneno`='$phoneno', `hirestatus`='$hirestatus', `hourssalary`='$hourssalary', `age`='$age', `address`='$address', `password`='$password' WHERE `nic`='$nic'";
    if (mysqli_query($conn, $query)) {
        header('Location: employee.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
