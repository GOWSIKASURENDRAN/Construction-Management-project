<?php include('inc/header.php'); ?>
<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/employeeform.css">
    <link rel="stylesheet" href="css/addcustomer.css">
    <script src="js/employeeform.js" defer></script>
    <title>Add Employee</title>
</head>
<body>
    <div class="container">
        <form id="addEmployeeForm" action="insertemployee.php" method="POST" enctype="multipart/form-data">
            <h1>Employee Details</h1>

            <div class="inputgroup">
                <label for="nic">NIC:</label>
                <input type="text" id="nic" name="nic" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required pattern="[A-Za-z\s]+" title="Name must contain only letters.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="gender">Gender:</label>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="male" name="gender" value="male">
                        <label for="male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="female" name="gender" value="female">
                        <label for="female">Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="other" name="gender" value="other">
                        <label for="other">Prefer not to say</label>
                    </div>
                </div>
            </div>

            <div class="inputgroup">
                <label for="dateofjoin">Date of Joining:</label>
                <input type="date" id="dateofjoin" name="dateofjoin" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" readonly required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="jobtitle">Job Title:</label>
                <input type="text" id="jobtitle" name="jobtitle" required pattern="[A-Za-z\s]+" title="Job title must contain only letters.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="category">Employee Category:</label>
                <select name="empcat" id="category">
                    <option value="Fulltime">Fulltime</option>
                    <option value="Parttime">Parttime</option>
                </select>
            </div>

            <div class="inputgroup">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="phoneno">Phone No:</label>
                <input type="text" id="phoneno" name="phoneno" required pattern="\d{10}" title="Phone number must be 10 digits.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="hirestatus">Hire Status:</label>
                <select name="hirestatus" id="hirestatus">
                    <option value="Available">Available</option>
                    <option value="NotAvailable">Not Available</option>
                </select>
            </div>

            <div class="inputgroup">
                <label for="hourssalary">Hourly Salary:</label>
                <input type="number" id="hourssalary" name="hourssalary" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="age">Age:</label>
                <input type="number" id="age" name="age" readonly required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="pw">Password:</label>
                <input type="password" id="pw" name="pw" required minlength="8" title="Password must be at least 8 characters long and include a mix of uppercase, lowercase, numbers, and special characters.">
                <div class="error">required</div>
            </div>

            <div class="inputgroup">
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
                <div class="error">required</div>
            </div>

            <button id="button" type="submit">Register</button>
        </form>
    </div>

    <script>
        document.getElementById('nic').addEventListener('input', function() {
            var nic = this.value;
            var dobInput = document.getElementById('dob');
            var genderRadios = document.getElementsByName('gender');
            var ageInput = document.getElementById('age');

            if (validateNIC(nic)) {
                var details = extractNICDetails(nic);
                dobInput.value = details.dob;
                genderRadios.forEach(function(radio) {
                    if (radio.value === details.gender.toLowerCase()) {
                        radio.checked = true;
                    }
                });
                var age = calculateAge(new Date(details.dob));
                ageInput.value = age;
            }
        });

        function validateNIC(nic) {
            // Check if NIC is either 10 characters with a letter or 12 digit number
            return /^(\d{9}[vVxX]|\d{12})$/.test(nic);
        }

        function extractNICDetails(nic) {
            var year, dayList;
            if (nic.length === 10) {
                year = "19" + nic.substr(0, 2);
                dayList = parseInt(nic.substr(2, 3));
            } else if (nic.length === 12) {
                year = nic.substr(0, 4);
                dayList = parseInt(nic.substr(4, 3));
            }
            var dobDetails = getDOB(dayList, year);
            return {
                dob: dobDetails.dob,
                gender: dobDetails.gender
            };
        }

        function getDOB(dayList, year) {
            var gender = dayList > 500 ? 'Female' : 'Male';
            if (gender === 'Female') dayList -= 500;

            var d_array = [
                { month: '01', days: 31 },
                { month: '02', days: 29 },
                { month: '03', days: 31 },
                { month: '04', days: 30 },
                { month: '05', days: 31 },
                { month: '06', days: 30 },
                { month: '07', days: 31 },
                { month: '08', days: 31 },
                { month: '09', days: 30 },
                { month: '10', days: 31 },
                { month: '11', days: 30 },
                { month: '12', days: 31 }
            ];

            var day = dayList, month = '';
            for (var i = 0; i < d_array.length; i++) {
                if (day > d_array[i].days) {
                    day -= d_array[i].days;
                } else {
                    month = d_array[i].month;
                    break;
                }
            }

            return { dob: year + '-' + month + '-' + day.toString().padStart(2, '0'), gender: gender };
        }

        function calculateAge(dob) {
            var diff = Date.now() - dob.getTime();
            var ageDate = new Date(diff);
            return Math.abs(ageDate.getUTCFullYear() - 1970);
        }

        document.getElementById('addEmployeeForm').addEventListener('submit', function(event) {
            var password = document.getElementById('pw').value;
            var confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match.');
                event.preventDefault();
            }
        });
    </script>
</body>
</html>
<?php include('inc/footer.php'); ?>
