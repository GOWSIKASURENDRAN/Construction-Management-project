<?php
include('dbcon/config.php');
session_start();

if (isset($_GET['productId'])) {
    $productId = $_GET['productId'];
    $query = "SELECT * FROM tbl_product WHERE productId = $productId";
    $result = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        $productName = $row['productName'];
        $price = $row['price'];
        $image = $row['image'];

        $cartArray = array(
            $productId => array(
                'productName' => $productName,
                'price' => $price,
                'quantity' => 1,
                'image' => $image
            )
        );

        if (empty($_SESSION['cart'])) {
            $_SESSION['cart'] = $cartArray;
        } else {
            $array_keys = array_keys($_SESSION['cart']);
            if (in_array($productId, $array_keys)) {
                $_SESSION['cart'][$productId]['quantity'] += 1;
            } else {
                $_SESSION['cart'] = array_merge($_SESSION['cart'], $cartArray);
            }
        }
    }
    header('Location: cart.php');
}
?>
