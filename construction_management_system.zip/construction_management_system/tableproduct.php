<?php include 'inc/header.php';?>

<?php include('dbcon/config.php'); ?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Products - Trend-Build</title>
    <link rel="stylesheet" href="css/table.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #333333, #00fff7, #333333);
            margin: 0;
            padding: 0;
        }
        section {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 80%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }
        h1 {
            text-align: center;
            color: gray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: darkblue;
            color: gray;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: white;
        }
        img {
            max-width: 100px;
            border-radius: 8px;
        }
        a {
            color: blue;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .action-buttons a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <section>
        <h1>Our-Products</h1>
        <table>
            <tr>
                <th>Product Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
            <?php
            $query = "SELECT * FROM tbl_product";
            $result = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['productName'] . "</td>";
                echo "<td>" . $row['body'] . "</td>";
                echo "<td>LKR " . $row['price'] . "</td>";
                echo "<td><img src='images/" . $row['image'] . "' alt='" . $row['productName'] . "'></td>";
                echo "<td class='action-buttons'><a href='productdetail.php?productId=" . $row['productId'] . "'>Details</a> | <a href='addtocart.php?productId=" . $row['productId'] . "'>Add to Cart</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </section>
        </br>
        </br>
        </br>
        </br>
</body>
</html>
<?php include 'inc/footer.php';?>
