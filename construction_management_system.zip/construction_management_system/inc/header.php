<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trend-Build || Construction Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f4f4f4;
            color: #333;
            padding-top: 80px; 
        }

        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: linear-gradient(to right, black, gray, black);
            padding: 15px 30px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: fixed; 
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000; /* Keeps the nav bar on top of other content */
        }

        nav .logo a {
            font-size: 26px;
            font-weight: bold;
            color: black;
            text-decoration: none;
            padding: 10px 15px;
            transition: transform 0.3s ease;
        }

        nav .logo a:hover {
            transform: scale(1.1);
        }

        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        nav ul li {
            position: relative;
        }

        nav ul li a {
            font-size: 16px;
            color: white;
            text-decoration: none;
            padding: 10px 15px;
            display: inline-block;
            border-radius: 5px;
            transition: background-color 0.3s ease, color 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        nav ul li a:hover {
            background-color: lightblue;
            color: black;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }

        nav ul li a::before {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 0;
            background-color: lightblue;
            transition: width 0.3s;
        }

        nav ul li a:hover::before {
            width: 100%;
        }

        /* mobile */
        @media (max-width: 768px) {
            nav ul {
                flex-direction: column;
                gap: 10px;
            }

            nav {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>


    <nav>
        <label class="logo">
            <a style="background:transparent; color:white;" href="dashboard.php">TrendBuild</a>
        </label>
        <ul>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="tableproduct.php"><i class="fas fa-open-box"></i> Product</a></li>
            <li><a href="tablevehicle.php"><i class="fas fa-car"></i> Vehicle</a></li>
            <li><a href="tableemplyee.php"><i class="fas fa-user"></i> Employee</a></li>
            <li><a href="about.php"><i class="fas fa-about"></i> About</a></li>
            <li><a href="contactus.php"><i class="fas fa-phone-number"></i> Contact</a></li>
            <li><a href="cart.php"><i class="fas fa-cart"></i> cart</a></li>
            <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i></a></li>
        </ul>
    </nav>
    <section></section>


</body>
</html>
