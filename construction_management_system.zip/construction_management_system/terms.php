<html>
<head>
    <title>Terms and Conditions</title>
    <style>
	
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f4f4f9;
    color: #333;
}

header {
    background-color: #2c3e50;
    color: #fff;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
   
}

.page-login a {
    margin-left: 10px;
    color: #ecf0f1;
    text-decoration: none;
    font-weight: bold;

}


.terms {
    background-color: #34495e;
    padding: 20px;
    margin: 40px auto;
    border-radius: 10px;
    color: white;
    max-width: 800px;
}

.terms h2 {
    font-size: 20px;
    margin-bottom: 10px;
    color: #ecf0f1;
}

.terms-box {
    background-color: #ecf0f1;
    color: #2c3e50;
    padding: 20px;
    border-radius: 8px;
  
}

footer {
    background-color: #2c3e50;
    padding: 30px 20px;
    color: #ecf0f1;
    text-align: center;
}
.footer-nav button {
    margin: 10px;
    padding: 12px 20px;
    background-color: #1abc9c;
    color: #fff;
    border: none;
    border-radius:10px;
    font-size: 10px;
    cursor: pointer;
  
}


.abc {
    margin-top: 20px;
}


.abc button {
    padding: 10px 20px;
    background-color: #1abc9c;
    color: #fff;
    border: none;
    border-radius: 5px;
    font-size: 15px;
    cursor: pointer;

}

.abc button:hover {
    background-color: #16a085;
}

.footer-links {
    margin-top: 20px;
}

.footer-links a {
    color: #ecf0f1;
    margin: 0 10px;
    text-decoration: none;
    color: #fff;
}


.footer-links {
    margin-top: 20px;
    font-size: 20px;
}






</style>
</head>
<body>

    <main>
        <section class="terms">
            <h2>Terms and conditions</h2>
            <div class="terms-box">
                <p>Welcome to our Construction Management System.</p>
                <p>The system is provided "as is" and we make no warranties regarding its functionality or performance.
				We are not liable for any damages that may arise from your use of the system..We may update these Terms and Conditions at any time.
				Continued use of the system following any updates indicates your acceptance of the new terms.</p>

            
        </section>
    </main>
</body>
</html>
