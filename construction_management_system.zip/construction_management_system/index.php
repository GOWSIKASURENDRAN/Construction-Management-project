<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" href="css/login1.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/login.js" defer></script>
</head>
<body>
    <div class="cage">
        <form action="login.php" method="post" id="form">
            <h1>Login</h1>
            <div class="inputonly">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <div class="error"></div>
            </div>

            <div class="inputonly">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <div class="error"></div>
            </div>

            <div class="forgot">
                <a href="">Forgot Password</a>
            </div>

            <div class="button-group">
                <button type="submit" name="login">Login</button>
            </div>

            <div class="member">
                Not a member? <a href="signup.php">Register Now</a>
            </div>
        </form>
    </div>

    <?php
    include('dbcon/config.php');
    session_start();

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = mysqli_real_escape_string($conn, md5($_POST['password']));

        $query = "SELECT * FROM tbl_users WHERE username='$username' AND pass='$password'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            header('Location: dashboard.php');
        } else {
            echo "<div class='error'>Invalid username or password</div>";
        }
    }
    ?>
</body>
</html>

