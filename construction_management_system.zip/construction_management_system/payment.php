<?php include 'inc/header.php';?>
<?php
include('dbcon/config.php');
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Payment - Trend-Build</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <!-- Include your navigation bar here -->
    </nav>
    <section>
        <h1>Payment</h1>
        <form action="processpayment.php" method="post">
            <label for="paymentMethod">Select Payment Method:</label>
            <select id="paymentMethod" name="paymentMethod" required>
                <option value="cash_on_delivery">Cash on Delivery</option>
                <option value="bank_transfer">Bank Transfer</option>
            </select>
            <input type="submit" value="Submit">
        </form>
    </section>
</body>
</html>
