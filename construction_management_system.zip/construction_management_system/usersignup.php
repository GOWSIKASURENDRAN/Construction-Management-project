<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <style>
        body {
            background-color: white; /* White background */
            margin: 0;
        }
        #form {
            width: 300px;
            margin: 100pt auto 0 auto;
            background-color: lightgray; /* Light gray background for the form */
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Soft shadow */
        }
        h1 {
            text-align: center;
            color: black; /* Black text */
        }
        #form button {
            background-color: black; /* Black button */
            color: white; /* White text */
            border: 1px solid black; /* Black border */
            border-radius: 10px;
            padding: 3px;
            width: 300px;
            margin: 10px auto;
            cursor: pointer;
        }
        .button-group {
            text-align: center;
        }
        .inputonly {
            display: flex;
            flex-direction: column;
            margin-bottom: 10px;
        }
        .inputonly input {
            border-radius: 10px;
            margin-top: 5px;
            padding: 5px;
            border: 1px solid black; /* Black border */
            background-color: white; /* White input background */
            color: black; /* Black text in input */
        }
        .inputonly input:focus {
            outline: none;
            border-color: black; /* Black border on focus */
        }
        .inputonly.ok input {
            border-color: black; /* Black border for valid input */
        }
        .inputonly.no input {
            border-color: red; /* Red border for invalid input */
        }
        .member a {
            text-decoration: none;
            color: black; /* Black link color */
        }
        .member {
            font-size: small;
            text-align: center;
        }
        .error {
            color: red; /* Red for error messages */
            font-size: 10px;
            margin-top: 5px;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const form = document.querySelector('#form');
            const username = document.querySelector('#username');
            const email = document.querySelector('#email');
            const password = document.querySelector('#password');
            const cpassword = document.querySelector('#cpassword');

            form.addEventListener('submit', (e) => {
                if (!validateInputs()) {
                    e.preventDefault();
                }
            });

            function validateInputs() {
                const usernameValue = username.value.trim();
                const emailValue = email.value.trim();
                const passwordValue = password.value.trim();
                const cpasswordValue = cpassword.value.trim();

                let ok = true;

                if (usernameValue === '') {
                    ok = false;
                    setNo(username, 'Username is required⚠️');
                } else {
                    setOk(username);
                }

                if (emailValue === '') {
                    ok = false;
                    setNo(email, 'Email is required⚠️');
                } else if (!isValidEmail(emailValue)) {
                    ok = false;
                    setNo(email, 'Email is not valid⚠️');
                } else {
                    setOk(email);
                }

                if (passwordValue === '') {
                    ok = false;
                    setNo(password, 'Password is required⚠️');
                } else if (passwordValue.length < 8) {
                    ok = false;
                    setNo(password, 'Password must be at least 8 characters⚠️');
                } else {
                    setOk(password);
                }

                if (cpasswordValue === '') {
                    ok = false;
                    setNo(cpassword, 'Confirm Password is required⚠️');
                } else if (cpasswordValue !== passwordValue) {
                    ok = false;
                    setNo(cpassword, 'Passwords do not match⚠️');
                } else {
                    setOk(cpassword);
                }

                return ok; // return the validation result
            }

            function isValidEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email regex
                return re.test(String(email).toLowerCase());
            }

            function setNo(element, message) {
                const inputOnly = element.parentElement;
                const errorElement = inputOnly.querySelector('.error');

                errorElement.innerText = message;
                inputOnly.classList.add('no');
                inputOnly.classList.remove('ok');
            }

            function setOk(element) {
                const inputOnly = element.parentElement;
                const errorElement = inputOnly.querySelector('.error');

                errorElement.innerText = '';
                inputOnly.classList.add('ok');
                inputOnly.classList.remove('no');
            }
        });
    </script>
</head>
<body>
    <div class="cage">
        <form method="post" action="signup.php" id="form">
            <h1>Signup</h1>
            <div class="inputonly">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username">
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email">
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password">
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="cpassword">Confirm Password:</label>
                <input type="password" id="cpassword" name="cpassword">
                <div class="error"></div>
            </div>
            <div class="button-group">
                <button type="submit" value="signup">Sign Up</button>
            </div>
            <div class="member">
                Already a member? <a href="./login.php">Login Here</a>
            </div>
        </form>
    </div>
</body>
</html>
