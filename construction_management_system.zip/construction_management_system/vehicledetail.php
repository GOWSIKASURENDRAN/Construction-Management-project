<?php
include('dbcon/config.php');
session_start();

if (!isset($_GET['v_id'])) {
    header('Location: vehicles.php');
    exit();
}

$v_id = $_GET['v_id'];
$query = "SELECT v_id,v_name, v_model, v_yom, v_lsd, fueltype, image, capacity, milage, regno, rentstatus FROM tbl_vehicle WHERE v_id = $v_id";
$result = mysqli_query($conn, $query);
$vehicle = mysqli_fetch_assoc($result);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Vehicle Details - Trend-Build</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #333333, #00fff7, #333333);
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 50%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }
        h1 {
            text-align: center;
            color: gray;
        }
        .details {
            margin: 20px 0;
        }
        .details p {
            margin: 10px 0;
        }
        .details label {
            font-weight: bold;
        }
        .details img {
            max-width: 100%;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Vehicle Details</h1>
        <div class="details">
            <p><label>Vehicle Name:</label> <?php echo $vehicle['v_name']; ?></p>
            <p><label>Model:</label> <?php echo $vehicle['v_model']; ?></p>
            <p><label>Year of Manufacture:</label> <?php echo $vehicle['v_yom']; ?></p>
            <p><label>Last Service Date:</label> <?php echo $vehicle['v_lsd']; ?></p>
            <p><label>Fuel Type:</label> <?php echo $vehicle['fueltype']; ?></p>
            <p><label>Capacity:</label> <?php echo $vehicle['capacity']; ?></p>
            <p><label>Mileage:</label> <?php echo $vehicle['milage']; ?></p>
            <p><label>Registration Number:</label> <?php echo $vehicle['regno']; ?></p>
            <p><label>Rent Status:</label> <?php echo $vehicle['rentstatus']; ?></p>
            <p><label>Image:</label><br><img src="images/<?php echo $vehicle['image']; ?>" alt="<?php echo $vehicle['v_name']; ?>"></p>
        </div>
    </div>
</body>
</html>
