<?php include 'inc/header.php';?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Order Confirmation - Trend-Build</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
    </nav>
    <section>
        <h1>Order Confirmation</h1>
        <p>Thank you for your order! Your order has been placed successfully and is currently pending. We will contact you shortly to confirm the details.</p>
    </section>
</body>
</html>
