<?php
include 'dbcon/config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: profile.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT name, dob, address, dateofjoin, phone, email, pass FROM tbl_customer WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $dateofjoin = mysqli_real_escape_string($conn, $_POST['dateofjoin']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "UPDATE tbl_customer SET name='$name', dob='$dob', address='$address', dateofjoin='$dateofjoin', phone='$phone', email='$email', pass='$password' WHERE id=$user_id";
    if (mysqli_query($conn, $sql)) {
        echo "Profile updated successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, rgba(173, 216, 230, 0.6), rgba(255, 255, 255, 0.8), rgba(173, 216, 230, 0.6));
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .container {
            width: 50%;
            margin: auto;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            border-radius: 10px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .inputonly {
            margin-bottom: 15px;
        }

        .inputonly label {
            display: block;
            margin-bottom: 5px;
        }

        .inputonly input, .inputonly textarea {
            width: 100%;
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .button-group {
            text-align: center;
        }

        .button-group button {
            background-color: rgb(0, 191, 255);
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .button-group button:hover {
            background-color: #007BFF;
            transform: scale(1.05);
        }

        .error {
            color: red;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Profile</h1>
        <form method="post" action="">
            <div class="inputonly">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo $user['name']; ?>" required>
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" value="<?php echo $user['dob']; ?>" required>
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="address">Address:</label>
                <textarea id="address" name="address" required><?php echo $user['address']; ?></textarea>
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="dateofjoin">Date of Joining:</label>
                <input type="date" id="dateofjoin" name="dateofjoin" value="<?php echo $user['dateofjoin']; ?>" required>
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" value="<?php echo $user['phone']; ?>" required>
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                <div class="error"></div>
            </div>
            <div class="inputonly">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" value="<?php echo $user['pass']; ?>" required>
                <div class="error"></div>
            </div>
            <div class="button-group">
                <button type="submit">Update Profile</button>
            </div>
        </form>
    </div>
</body>
</html>
