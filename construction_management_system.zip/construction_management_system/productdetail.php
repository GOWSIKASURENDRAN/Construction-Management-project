<?php include('dbcon/config.php'); ?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Product Details - Trend-Build</title>
    <link rel="stylesheet" href="css/table.css">
</head>
<body>
    <nav>
    </nav>
    <section>
        <?php
        if (isset($_GET['productId'])) {
            $productId = $_GET['productId'];
            $query = "SELECT * FROM tbl_product WHERE productId = $productId";
            $result = mysqli_query($conn, $query);
            if ($row = mysqli_fetch_assoc($result)) {
                echo "<h1>" . $row['productName'] . "</h1>";
                echo "<p>" . $row['body'] . "</p>";
                echo "<p>Price: LKR " . $row['price'] . "</p>";
                echo "<img src='images/" . $row['image'] . "' alt='" . $row['productName'] . "' width='300'>";
                echo "<p><a href='addtocart.php?productId=" . $row['productId'] . "'>Add to Cart</a></p>";
            } else {
                echo "<p>Product not found.</p>";
            }
        } else {
            echo "<p>No product selected.</p>";
        }
        ?>
    </section>
</body>
</html>
