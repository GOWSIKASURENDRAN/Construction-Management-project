<?php include 'inc/header.php';?>

<?php include('dbcon/config.php'); ?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Vehicles for Hire - Trend-Build</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #333333, #00fff7, #333333);
            margin: 0;
            padding: 0;
        }
        section {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 80%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }
        h1 {
            text-align: center;
            color: gray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: darkblue;
            color: gray;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: white;
        }
        img {
            max-width: 100px;
            border-radius: 8px;
        }
        a {
            color: blue;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .action-buttons a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <section>
        <h1>Vehicles for Hire</h1>
        <table>
            <tr>
                <th>Vehicle Name</th>
                <th>Model</th>
                <th>Year of Manufacture</th>
                <th>Last Service Date</th>
                <th>Fuel Type</th>
                <th>Image</th>
                <th>Capacity</th>
                <th>Mileage</th>
                <th>Registration Number</th>
                <th>Rent Status</th>
                <th>Action</th>
            </tr>
            <?php
            $query = "SELECT v_name, v_model, v_yom, v_lsd, fueltype, image, capacity, milage, regno, rentstatus FROM tbl_vehicle";
            $result = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['v_name'] . "</td>";
                echo "<td>" . $row['v_model'] . "</td>";
                echo "<td>" . $row['v_yom'] . "</td>";
                echo "<td>" . $row['v_lsd'] . "</td>";
                echo "<td>" . $row['fueltype'] . "</td>";
                echo "<td><img src='images/" . $row['image'] . "' alt='" . $row['v_name'] . "'></td>";
                echo "<td>" . $row['capacity'] . "</td>";
                echo "<td>" . $row['milage'] . "</td>";
                echo "<td>" . $row['regno'] . "</td>";
                echo "<td>" . $row['rentstatus'] . "</td>";
                echo "<td class='action-buttons'><a href='vehicledetail.php?v_id=" . $row['v_id'] . "'>Details</a> | <a href='hirevehicle.php?v_id=" . $row['v_id'] . "'>Hire</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </section>
</body>
</html>
<?php include 'inc/footer.php';?>
