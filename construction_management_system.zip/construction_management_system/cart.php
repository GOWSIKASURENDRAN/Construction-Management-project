<?php
include('dbcon/config.php');
session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Shopping Cart - Trend-Build</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #333333, #00fff7, #333333);
            margin: 0;
            padding: 0;
        }
        section {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 80%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }
        h1 {
            text-align: center;
            color: gray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: darkblue;
            color: gray;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: white;
        }
        a {
            color: blue;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .action-buttons a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <nav>
        <!-- Include your navigation bar here -->
    </nav>
    <section>
        <h1>Your Shopping Cart</h1>
        <?php
        if (!empty($_SESSION['cart'])) {
            $total = 0;
        ?>
        <table>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
            <?php
            foreach ($_SESSION['cart'] as $key => $product) {
                $productTotal = $product['price'] * $product['quantity'];
                $total += $productTotal;
            ?>
            <tr>
                <td><?php echo $product['productName']; ?></td>
                <td>
                    <form method="post" action="updatecart.php">
                        <input type="hidden" name="productId" value="<?php echo $key; ?>">
                        <input type="number" name="quantity" value="<?php echo $product['quantity']; ?>" min="1">
                        <input type="submit" value="Update">
                    </form>
                </td>
                <td>LKR <?php echo $product['price']; ?></td>
                <td>LKR <?php echo $productTotal; ?></td>
                <td><a href="removecart.php?productId=<?php echo $key; ?>">Remove</a></td>
            </tr>
            <?php } ?>
            <tr>
                <td colspan="3">Total</td>
                <td>LKR <?php echo $total; ?></td>
                <td></td>
            </tr>
        </table>
        <p><a href="checkout.php">Proceed to Checkout</a></p>
        <?php
        } else {
            echo "<p>Your cart is empty.</p>";
        }
        ?>
    </section>
</body>
</html>
