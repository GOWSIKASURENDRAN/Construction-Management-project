<?php
include 'dbcon/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $sql = "INSERT INTO subsemail (email) VALUES ('$email')";
    if (mysqli_query($conn, $sql)) {
        echo "Subscription successful!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>
