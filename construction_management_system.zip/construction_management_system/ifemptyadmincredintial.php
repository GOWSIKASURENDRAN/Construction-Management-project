<?php
include('dbcon/config.php');

$adminName = 'zeroprogrammers';
$adminUser = 'superadmin'; //default un
$adminEmail = 'zero@sliit.lk'; //default email
$adminPassword ='12345678'; //default pw
$level = 'superadmin';

$query = "INSERT INTO tbl_admin (`adminName`, `adminUser`, `adminEmail`, `adminPassword`, `level`) VALUES ('$adminName', '$adminUser', '$adminEmail', '$adminPassword', '$level')";
if (mysqli_query($conn, $query)) {
    echo "zeroprogrammers user created successfully.";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
