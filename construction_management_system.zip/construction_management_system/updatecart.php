<?php
session_start();
if (isset($_POST['productId']) && isset($_POST['quantity'])) {
    $productId = $_POST['productId'];
    $quantity = $_POST['quantity'];
    if ($quantity > 0) {
        $_SESSION['cart'][$productId]['quantity'] = $quantity;
    }
    header('Location: cart.php');
}
?>
