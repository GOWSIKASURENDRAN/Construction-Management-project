<?php include 'inc/header.php';?>

<?php include('dbcon/config.php'); ?>
<!DOCTYPE HTML>
<html>
<head>
    <title>Hire Employees - Trend-Build</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #333333, #00fff7, #333333);
            margin: 0;
            padding: 0;
        }
        section {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 80%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }
        h1 {
            text-align: center;
            color: gray;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background-color: white;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: darkblue;
            color: gray;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: white;
        }
        a {
            color: blue;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        .action-buttons a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <section>
        <h1>Hire Employees</h1>
        <table>
            <tr>
                <th>Name</th>
                <th>Gender</th>
                <th>Date of Joining</th>
                <th>Date of Birth</th>
                <th>Job Title</th>
                <th>Employee Category</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Hire Status</th>
                <th>Hourly Salary</th>
                <th>Age</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
            <?php
            $query = "SELECT name, gender, doj, dob, jobtitle, empcat, Email, phoneno, hirestatus, hourssalary, age, address, pw FROM tbl_employee";
            $result = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['gender'] . "</td>";
                echo "<td>" . $row['doj'] . "</td>";
                echo "<td>" . $row['dob'] . "</td>";
                echo "<td>" . $row['jobtitle'] . "</td>";
                echo "<td>" . $row['empcat'] . "</td>";
                echo "<td>" . $row['Email'] . "</td>";
                echo "<td>" . $row['phoneno'] . "</td>";
                echo "<td>" . $row['hirestatus'] . "</td>";
                echo "<td>" . $row['hourssalary'] . "</td>";
                echo "<td>" . $row['age'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                echo "<td class='action-buttons'><a href='employeedetail.php?emp_id=" . $row['id'] . "'>Details</a> | <a href='hireemployee.php?emp_id=" . $row['id'] . "'>Hire</a></td>";
                echo "</tr>";
            }
            ?>
        </table>
    </section>
</body>
</html>
<?php include 'inc/footer.php';?>
