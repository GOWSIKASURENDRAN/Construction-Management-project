<?php
session_start();
if (isset($_GET['productId'])) {
    $productId = $_GET['productId'];
    unset($_SESSION['cart'][$productId]);
    header('Location: cart.php');
}
?>
