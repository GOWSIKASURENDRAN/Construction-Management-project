<!DOCTYPE html>
<html>
<head>
    <title>Signup Page</title>
    <link rel="stylesheet" href="css/signup.css">
</head>
<?php
include 'dbcon/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = md5(mysqli_real_escape_string($conn, $_POST['password']));

    $sql = "INSERT INTO tbl_users (name, dob, address, phone, email, username, pass) VALUES ('$name', '$dob', '$address', '$phone', '$email', '$username', '$password')";
    if (mysqli_query($conn, $sql)) {
        echo "Registration successful!";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>

<body>
    <div class="cage">
        <form method="post" action="" id="form" onsubmit="return validateForm()">
            <h1>Signup</h1>
            <div class="inputonly">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
                <div class="error" id="nameError"></div>
            </div>
            <div class="inputonly">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" name="dob" required>
                <div class="error" id="dobError"></div>
            </div>
            <div class="inputonly">
                <label for="address">Address:</label>
                <textarea id="address" name="address" required></textarea>
                <div class="error" id="addressError"></div>
            </div>
            <div class="inputonly">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" required>
                <div class="error" id="phoneError"></div>
            </div>
            <div class="inputonly">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
                <div class="error" id="emailError"></div>
            </div>
            <div class="inputonly">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <div class="error" id="usernameError"></div>
            </div>
            <div class="inputonly">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <div class="error" id="passwordError"></div>
            </div>
            <div class="inputonly">
                <label for="cpassword">Confirm Password:</label>
                <input type="password" id="cpassword" name="cpassword" required>
                <div class="error" id="cpasswordError"></div>
            </div>
            <div class="button-group">
                <button type="submit" value="signup">Register</button>
                <button type="button" id="cancel-button">Cancel</button>
            </div>

            <div class="member">
                Already a member? <a href="index.php">Login Here</a>
            </div>
        </form>
    </div>

    <script>
        function validateForm() {
            let valid = true;

            // Name validation
            const name = document.getElementById('name').value;
            if (name.trim() === '') {
                document.getElementById('nameError').innerText = 'Name is required';
                valid = false;
            } else {
                document.getElementById('nameError').innerText = '';
            }

            // Date of Birth validation
            const dob = document.getElementById('dob').value;
            const today = new Date().toISOString().split('T');
            if (dob >= today) {
                document.getElementById('dobError').innerText = 'Date of Birth cannot be in the future';
                valid = false;
            } else {
                document.getElementById('dobError').innerText = '';
            }

            // Phone validation
            const phone = document.getElementById('phone').value;
            const phonePattern = /^0\d{9}$/;
            if (!phonePattern.test(phone)) {
                document.getElementById('phoneError').innerText = 'Phone number must be 10 digits and start with 0';
                valid = false;
            } else {
                document.getElementById('phoneError').innerText = '';
            }

            // Email validation
            const email = document.getElementById('email').value;
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                document.getElementById('emailError').innerText = 'Invalid email format';
                valid = false;
            } else {
                document.getElementById('emailError').innerText = '';
            }

            // Password validation
            const password = document.getElementById('password').value;
            if (password.length < 6) {
                document.getElementById('passwordError').innerText = 'Password must be at least 6 characters long';
                valid = false;
            } else {
                document.getElementById('passwordError').innerText = '';
            }

            // Confirm Password validation
            const cpassword = document.getElementById('cpassword').value;
            if (password !== cpassword) {
                document.getElementById('cpasswordError').innerText = 'Passwords do not match';
                valid = false;
            } else {
                document.getElementById('cpasswordError').innerText = '';
            }

            return valid;
        }
    </script>
</body>
</html>
