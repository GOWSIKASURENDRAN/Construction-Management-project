<?php include 'inc/header.php';?>
<?php
include('dbcon/config.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $paymentMethod = $_POST['paymentMethod'];
    $customerId = $_SESSION['cmrId'];
    $orderTotal = 0;

    foreach ($_SESSION['cart'] as $productId => $product) {
        $orderTotal += $product['price'] * $product['quantity'];
    }

    $query = "INSERT INTO tbl_order (customerId, paymentMethod, orderTotal, orderStatus) VALUES ('$customerId', '$paymentMethod', '$orderTotal', 'Pending')";
    if (mysqli_query($conn, $query)) {
        $orderId = mysqli_insert_id($conn);
        foreach ($_SESSION['cart'] as $productId => $product) {
            $productName = $product['productName'];
            $quantity = $product['quantity'];
            $price = $product['price'];
            $query = "INSERT INTO tbl_orderdetails (orderId, productId, productName, quantity, price) VALUES ('$orderId', '$productId', '$productName', '$quantity', '$price')";
            mysqli_query($conn, $query);
        }
        unset($_SESSION['cart']);
        header('Location: orderconfirmation.php');
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
