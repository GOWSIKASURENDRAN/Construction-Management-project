<?php include 'inc/header.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
   
    <style>
        /* Add a basic reset for padding and margin */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            background-color: #f0f4f8; /* Light background */
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            font-family: Arial, sans-serif; /* Font for the page */
        }
        .container {
            width: 1000px; /* Fixed width for the container */
            background: linear-gradient(to right, darkblue, #00fff7);
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6); /* Box shadow for the container */
            padding: 60px; /* Increased padding */
            border-radius: 15px; /* Rounded corners */
            display: grid;
            grid-template-columns: 60% 40%; /* Column layout */
            gap: 30px; /* Space between columns */
        }
        h3 {
            font-size: 36px; /* Header size */
            color: white; /* Header color */
            text-align: center; /* Center align */
            margin-bottom: 20px; /* Space below header */
        }
        p, label, .contact-info p, .contact-info a {
            font-size: 20px; /* Font size for text elements */
            color: white; /* Text color */
        }
        input, textarea {
            width: 100%; /* Full width */
            padding: 15px; /* Padding */
            font-size: 20px; /* Font size */
            border-radius: 8px; /* Rounded corners */
            background-color: white; /* White background */
            border: 1px solid #ccc; /* Light grey border */
            margin-bottom: 25px; /* Space below inputs */
            color: black; /* Text color */

            transition: border 0.3s; /* Transition for border on focus */
        }
        input:focus, textarea:focus {
            border: 1px solid darkblue; /* Change border color on focus */
            outline: none; /* Remove outline */
        }
        button {
            cursor: pointer;
            background: linear-gradient(to right,  #00fffb,white);
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);a/* White background for button */
            color: black; /* Text color */
            font-size: 20px; /* Font size */
            padding: 15px 25px; /* Padding */
            border: none; /* Remove default border */
            border-radius: 8px; /* Rounded corners */
            transition: background-color 0.3s, transform 0.3s; /* Transition effects */
        }
        button:hover {
            background-color: #e0f7fa; /* Change background on hover */
            transform: translateY(-2px); /* Slight lift effect */
        }
        .contact-details {
            margin-top: 40px; /* Space above details */
            display: flex;
            flex-direction: column;
            gap: 20px; /* Space between details */
            font-size: 20px; /* Font size */
        }
        .contact-info {
            display: flex;
            align-items: center;
            gap: 15px; /* Space between info */
        }
        .contact-info p, .contact-info a {
            margin: 0; /* Remove margin */
            font-size: 20px; /* Font size */
            text-decoration: none; /* Remove underline */
            color: white; /* Text color */
        }
        .contact-image {
            text-align: center; /* Center align image */
            margin-top: 40px; /* Space above image */
        }
        .contact-image img {
            width: 350px; /* Image width */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3); /* Shadow for image */
        }
        .social-icons {
            position: absolute; /* Positioning */
            right: 50px; /* Distance from right */
            bottom: 150px; /* Distance from bottom */
            display: flex;
            flex-direction: column;
            gap: 15px; /* Space between icons */
            font-size: 30px; /* Icon size */
        }
        .social-icons a {
            color: white; /* Icon color */
            text-decoration: none; /* Remove underline */
            transition: transform 0.3s; /* Transition for icons */
        }
        .social-icons a:hover {
            transform: scale(1.1); /* Scale up on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div>
            <h3>Get in Touch</h3>
            <p>We are here for you! How can we help you?</p>
            <form action="contact.php" id="form">
                <div>
                    <label for="name">First Name:</label>
                    <input type="text" id="name" name="name" placeholder="Enter your first name" required>
                </div>
                <div>
                    <label for="mail">Email:</label>
                    <input type="email" id="mail" name="mail" placeholder="Enter your email" required>
                </div>
                <div>
                    <label for="message">Message:</label>
                    <textarea id="message" name="message" placeholder="Enter your message" style="height: 250px;" required></textarea>
                </div>
                <button type="submit">Submit</button>
            </form>
        </div>
        <div>
            <div class="contact-image">
                <img src="images/1.png" alt="Contact Image">
            </div>
            <div class="contact-details">
                <div class="contact-info">
                    <p>123 street, Jaffna, Sri Lanka</p>
                </div>
                <div class="contact-info">
                    <a href="tel:123-456-789">123-456-789</a>
                </div>
                <div class="contact-info">
                    <a href="mailto:hihello1234@gmail.com">hihello1234@gmail.com</a>
                </div>
            </div>
        </div>
        
    </div>
</body>
</html>
<?php include('inc/footer.php'); ?>