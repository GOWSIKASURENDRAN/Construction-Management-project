<?php include 'inc/header.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trend-Build || Construction Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5; /* Set a background color */
        }

        .features {
            padding: 50px 5%;
            background-color: #ffffff; /* White background for features section */
            text-align: center;
        }

        .features h3 {
            font-size: 36px;
            margin-bottom: 50px;
            color: gray;
        }

        .features-container {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .feature {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            width: 25%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
            transition: transform 0.3s ease;
            margin-bottom: 20px;
        }

        .feature i {
            font-size: 50px;
            color: blue;
            margin-bottom: 20px;
        }

        .feature h4 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .feature p {
            font-size: 16px;
        }

        .feature:hover {
            transform: translateY(-10px);
        }

        /* Slider */
        .slider {
            position: relative;
            width: 100%; /* Minimize slider width */
            margin: auto;
            overflow: hidden;
        }

        .slides {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }

        .slide {
            min-width: 100%;
            box-sizing: border-box;
            background: linear-gradient(to right,#333333,white,#333333);
        }

        .slide img {
            width: 200%; /* Maintain responsiveness */
            height: auto; /* Maintain aspect ratio */
            max-width: 800px; /* Set a max width to minimize size */
            display: block;
            margin: 0 auto; /* Center align image */
        }

        /* Navigation buttons */
        .prev, .next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
        
            background: linear-gradient(to right, white, #00fff7);
            border: none;
            padding: 10px;
            cursor: pointer;
        }

        .prev {
            left: 20px;
        }

        .next {
            right: 20px;
        }

        .prev:hover, .next:hover {
            background-color: red;
        }
    </style>
</head>
<body>
    <div class="slider">
        <div class="slides">
            <div class="slide">
                <img src="images/1.jpg" alt="Image 1">
            </div>
            <div class="slide">
                <img src="images/2.jpg" alt="Image 2">
            </div>
            <div class="slide">
                <img src="images/3.jpg" alt="Image 3">
            </div>
            <div class="slide">
                <img src="images/4.jpg" alt="Image 4">
            </div>
        </div>
        <button class="prev" onclick="moveSlide(-1)">❮</button>
        <button class="next" onclick="moveSlide(1)">❯</button>
    </div>
    <section class="features">
        <h3>Our Features</h3>
        <div class="features-container">
            <div class="feature">
                <i class="fas fa-car"></i>
                <h4><a href="tableemployee.php">Hire Vehicle</a></h4>
                <p>Convenient vehicle rental services.</p>
            </div>
            <div class="feature">
                <i class="fas fa-box-open"></i>
                <h4><a href="tableproduct.php">User</a></h4>
                <p>Quality construction materials and tools.</p>
            </div>
            <div  class="feature">
                <i class="fas fa-user-shield"></i>
                <h4><a href="tablevehicle.php">User</a></h4>
                <p>User-friendly interface and support.</p>
            </div>
        </div>
    </section>

    <script>
        let slideIndex = 0;
        const slides = document.querySelector('.slides');
        const totalSlides = document.querySelectorAll('.slide').length;

        function moveSlide(n) {
            slideIndex += n;
            if (slideIndex >= totalSlides) {
                slideIndex = 0;
            } else if (slideIndex < 0) {
                slideIndex = totalSlides - 1;
            }
            updateSlidePosition();
        }

        function updateSlidePosition() {
            slides.style.transform = `translateX(-${slideIndex * 100}%)`;
        }

        // Auto slide
        setInterval(() => {
            moveSlide(1);
        }, 5000); // Change slide every 5 seconds

        // Cookie functions
        function setCookie(name, value, days) {
            const d = new Date();
            d.setTime(d.getTime() + (days*24*60*60*1000));
            const expires = "expires="+ d.toUTCString();
            document.cookie = name + "=" + value + ";" + expires + ";path=/";
        }

        function getCookie(name) {
            const cname = name + "=";
            const decodedCookie = decodeURIComponent(document.cookie);
            const ca = decodedCookie.split(';');
            for(let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(cname) == 0) {
                    return c.substring(cname.length, c.length);
                }
            }
            return "";
        }

        function checkCookie() {
            let user = getCookie("username");
            if (user != "") {
                alert("Welcome again " + user);
            } else {
                user = prompt("Please enter your name:", "");
                if (user != "" && user != null) {
                    setCookie("username", user, 365);
                }
            }
        }

        // Check for cookies on page load
        window.onload = checkCookie;
    </script>

    <?php include 'inc/footer.php';?>
</body>
</html>
