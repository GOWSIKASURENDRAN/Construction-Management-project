<?php
include('dbcon/config.php');
session_start();

if (!isset($_GET['emp_id'])) {
    header('Location: employees.php');
    exit();
}

$emp_id = $_GET['emp_id'];
$query = "SELECT nic, name, gender, doj, dob, jobtitle, empcat, Email, phoneno, hirestatus, hourssalary, age, address FROM tbl_employee WHERE id = $emp_id";
$result = mysqli_query($conn, $query);
$employee = mysqli_fetch_assoc($result);
?>

<!DOCTYPE HTML>
<html>
<head>
    <title>Employee Details - Trend-Build</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #333333, #00fff7, #333333);
            margin: 0;
            padding: 0;
        }
        .container {
            padding: 20px;
            background-color: #fff;
            margin: 20px auto;
            width: 50%;
            box-shadow: 0 15px 45px rgba(7, 234, 255, 0.6);
        }
        h1 {
            text-align: center;
            color: gray;
        }
        .details {
            margin: 20px 0;
        }
        .details p {
            margin: 10px 0;
        }
        .details label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Employee Details</h1>
        <div class="details">
            <p><label>Name:</label> <?php echo $employee['name']; ?></p>
            <p><label>Gender:</label> <?php echo $employee['gender']; ?></p>
            <p><label>Date of Joining:</label> <?php echo $employee['doj']; ?></p>
            <p><label>Date of Birth:</label> <?php echo $employee['dob']; ?></p>
            <p><label>Job Title:</label> <?php echo $employee['jobtitle']; ?></p>
            <p><label>Employee Category:</label> <?php echo $employee['empcat']; ?></p>
            <p><label>Email:</label> <?php echo $employee['Email']; ?></p>
            <p><label>Phone Number:</label> <?php echo $employee['phoneno']; ?></p>
            <p><label>Hire Status:</label> <?php echo $employee['hirestatus']; ?></p>
            <p><label>Hourly Salary:</label> <?php echo $employee['hourssalary']; ?></p>
            <p><label>Age:</label> <?php echo $employee['age']; ?></p>
            <p><label>Address:</label> <?php echo $employee['address']; ?></p>
        </div>
    </div>
</body>
</html>
